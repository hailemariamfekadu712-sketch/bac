/* =========================================
   HABESHA EXAM CENTER
   File: api-client.js
   Purpose: Talk to the HEC backend (optional)

   Nothing loads this file yet, so the site works exactly as before.
   To turn the backend on, add to a page BEFORE this script:
       <script>window.HEC_API_URL = "https://your-api.example.com";</script>
       <script src="api-client.js"></script>
   Uses one new storage key, hec_api_token. It does not touch
   hec_users, hec_current_user or any other existing key.
========================================= */
(function () {
  "use strict";

  const TOKEN_KEY = "hec_api_token";

  function baseUrl() {
    const url = String(window.HEC_API_URL || "").replace(/\/+$/, "");
    return url ? url + "/api/v1" : "";
  }

  function getToken() {
    try { return localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { return ""; }
  }

  function setToken(token) {
    try {
      if (token) localStorage.setItem(TOKEN_KEY, token);
      else localStorage.removeItem(TOKEN_KEY);
    } catch (e) { /* storage unavailable */ }
  }

  async function request(method, path, body) {
    const base = baseUrl();
    if (!base) throw new ApiError(0, "NOT_CONFIGURED", "The backend address (window.HEC_API_URL) is not set.");

    const headers = { "Content-Type": "application/json" };
    const token = getToken();
    if (token) headers.Authorization = "Bearer " + token;

    let response;
    try {
      response = await fetch(base + path, {
        method: method,
        headers: headers,
        body: body === undefined ? undefined : JSON.stringify(body)
      });
    } catch (error) {
      throw new ApiError(0, "NETWORK", "Could not reach the server. Check your connection and try again.");
    }

    let data = null;
    try { data = await response.json(); } catch (e) { /* empty body */ }

    if (!response.ok) {
      const err = data && data.error ? data.error : {};
      if (response.status === 401 && token && err.code === "UNAUTHORIZED") setToken("");
      throw new ApiError(response.status, err.code || "ERROR", err.message || "The request failed.", err.details);
    }
    return data;
  }

  function ApiError(status, code, message, details) {
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.message = message;
    this.details = details;
  }
  ApiError.prototype = Object.create(Error.prototype);

  function query(params) {
    const search = new URLSearchParams();
    Object.keys(params || {}).forEach(function (key) {
      if (params[key] !== undefined && params[key] !== null && params[key] !== "") search.set(key, params[key]);
    });
    const text = search.toString();
    return text ? "?" + text : "";
  }

  window.HECApi = Object.freeze({
    ApiError: ApiError,
    isConfigured: function () { return Boolean(baseUrl()); },
    isSignedIn: function () { return Boolean(getToken()); },

    /* accounts */
    register: async function (data) { const r = await request("POST", "/auth/register", data); setToken(r.token); return r.user; },
    login: async function (email, password) { const r = await request("POST", "/auth/login", { email: email, password: password }); setToken(r.token); return r.user; },
    logout: function () { setToken(""); },
    me: async function () { return (await request("GET", "/users/me")).user; },
    updateProfile: function (patch) { return request("PATCH", "/users/me", patch); },
    changePassword: function (currentPassword, newPassword) { return request("POST", "/users/me/password", { currentPassword: currentPassword, newPassword: newPassword }); },
    saveSelection: function (selection) { return request("PUT", "/users/me/selection", selection); },

    /* catalogue */
    grades: function () { return request("GET", "/grades"); },
    examTypes: function (grade) { return request("GET", "/exam-types" + query({ grade: grade })); },
    subjects: function (selection) { return request("GET", "/subjects" + query(selection)); },

    /* exams: the server grades; correct answers arrive only after submit */
    startExam: function (options) { return request("POST", "/attempts", options); },
    saveAnswers: function (attemptId, answers, extra) { return request("PUT", "/attempts/" + encodeURIComponent(attemptId) + "/answers", Object.assign({ answers: answers }, extra || {})); },
    submitExam: function (attemptId, answers) { return request("POST", "/attempts/" + encodeURIComponent(attemptId) + "/submit", answers ? { answers: answers } : {}); },
    getAttempt: function (attemptId) { return request("GET", "/attempts/" + encodeURIComponent(attemptId)); },
    getResult: function (attemptId) { return request("GET", "/results/" + encodeURIComponent(attemptId)); },
    listAttempts: function (filters) { return request("GET", "/attempts" + query(filters)); },
    progress: function () { return request("GET", "/users/me/progress"); },

    /* planner, flashcards */
    getPlan: async function () { return (await request("GET", "/users/me/plan")).studyPlan; },
    savePlan: function (tasks) { return request("PUT", "/users/me/plan", { studyPlan: tasks }); },
    getFlashcards: async function () { return (await request("GET", "/users/me/flashcards")).flashcards; },
    saveFlashcards: function (cards) { return request("PUT", "/users/me/flashcards", { flashcards: cards }); },

    /* content */
    resources: function (filters) { return request("GET", "/resources" + query(filters)); },
    announcements: async function () { return (await request("GET", "/announcements")).announcements; }
  });
})();
