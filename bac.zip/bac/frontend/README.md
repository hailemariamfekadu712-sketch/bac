# Habesha Exam Center

Starter project with all planned pages and separate JavaScript files.

## Notes
- This is a blank scaffold; functionality and content have not been implemented yet.
- Keep all files in this root directory as requested.
- Add question data to the corresponding grade/collection/stream/subject JavaScript file.
- Confirm the applicable regional curriculum and examination subject list before publishing exam categories.
- For GitHub Pages, use relative links and avoid backend-only features unless a backend is added later.


## Team contribution applications
- `apply-contributors.html` is the student application information page for Grades 6, 8 and 12.
- Before publishing, paste the team's Google Form URL into `apply-config.js` as the value of `window.HEC_GOOGLE_FORM_URL`. Use the published responder link from Google Forms (usually starts with `https://docs.google.com/forms/`).
- Resource files should use direct downloadable URLs (such as PDF files) for offline saving. Add only verified resources the team is allowed to share. Streaming video links may not support offline downloads.
- The archive has files at its top level so `index.html` can be uploaded to the repository root.


## Backend (added)
- The API lives in the sibling `backend/` folder. See its README.
- `api-client.js` is an optional client; no page loads it yet.
- Question-bank files are now complete for every subject in `subjects.js` (54 files). They are generated from `backend/question-banks/`; edit them there and run `npm run sync:banks -- ../frontend`.
- Older blank placeholders whose names match no subject (for example `grade6-addis-music.js`) are unused by the site.
