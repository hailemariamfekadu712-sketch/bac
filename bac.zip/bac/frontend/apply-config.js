/* Add the team's published Google Forms URL below. Example: https://docs.google.com/forms/d/e/FORM_ID/viewform */
window.HEC_GOOGLE_FORM_URL = "";
