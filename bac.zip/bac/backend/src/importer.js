'use strict';
const fs = require('node:fs');
const path = require('node:path');
const catalogue = require('./catalogue');
const { parseBankSource } = require('./bank-parser');

/**
 * Scan a folder of grade*-*.js bank files. Pure: touches no database.
 * Returns one entry per file plus the catalogue banks that have no file.
 */
function scanBankDirectory(dir) {
  const report = { dir, files: [], missing: [], unknown: [] };
  const names = fs.existsSync(dir) ? fs.readdirSync(dir).filter(n => /^grade.*\.js$/.test(n)).sort() : [];
  const seenKeys = new Map();

  for (const name of names) {
    const resolved = catalogue.resolveBankFilename(name);
    if (!resolved.ok) {
      report.unknown.push({ file: name, reason: resolved.reason === 'unknown-subject'
        ? 'No subject in the catalogue matches this file name, so it was not imported.'
        : 'File name does not follow gradeN-region-subject.js.' });
      continue;
    }
    const bank = resolved.bank;
    if (seenKeys.has(bank.key)) {
      report.unknown.push({ file: name, reason: `Duplicate of ${seenKeys.get(bank.key)} (same subject); skipped.` });
      continue;
    }
    seenKeys.set(bank.key, name);

    const source = fs.readFileSync(path.join(dir, name), 'utf8');
    const parsed = parseBankSource(source, bank);
    report.files.push({
      file: name, key: bank.key, bank, aliasOf: resolved.alias ? bank.filename : null,
      total: parsed.total, valid: parsed.questions.length,
      published: parsed.questions.filter(q => q.status === 'published').length,
      errors: parsed.errors, warnings: parsed.warnings, questions: parsed.questions
    });
  }
  for (const b of catalogue.allBanks()) if (!seenKeys.has(b.key)) report.missing.push(b.filename);
  return report;
}

/** Scan, then sync every valid bank into the store. */
async function importBanks(store, dir) {
  const report = scanBankDirectory(dir);
  const existing = await store.bankCounts();
  for (const f of report.files) {
    // A blank file must not wipe questions that were added through the admin API.
    if (f.valid === 0 && (existing[f.key] || 0) > 0) {
      f.keptDatabase = true;
      continue;
    }
    await store.replaceBank(f.key, {
      grade: f.bank.grade, region: f.bank.region, stream: f.bank.stream,
      subject: f.bank.subject, subjectTitle: f.bank.subjectTitle
    }, f.questions);
  }
  return summarize(report);
}

function summarize(report) {
  const files = report.files.map(f => ({
    file: f.file, key: f.key, aliasOf: f.aliasOf, total: f.total, valid: f.valid, published: f.published,
    errors: f.errors, warnings: f.warnings.length, keptDatabase: Boolean(f.keptDatabase)
  }));
  const totals = files.reduce((a, f) => ({ total: a.total + f.total, valid: a.valid + f.valid, published: a.published + f.published,
    errors: a.errors + f.errors.length }), { total: 0, valid: 0, published: 0, errors: 0 });
  return {
    files, missing: report.missing, unknown: report.unknown, totals,
    banksWithQuestions: files.filter(f => f.published > 0).length,
    banksExpected: catalogue.allBanks().length
  };
}

module.exports = { scanBankDirectory, importBanks, summarize };
