'use strict';
/*
  Reads a question-bank file written for the frontend:

      window.HEC_QUESTION_BANK = { subject: "english", questions: [ ... ] };

  The file is executed in an empty sandbox (no require, no process, no network)
  with a 1-second limit, then every question is validated. Nothing is silently
  dropped: every rejected question is reported with its position and reason.
*/
const vm = require('node:vm');
const { slugify } = require('./catalogue');

const MAX_OPTIONS = 6;
const STATUSES = ['published', 'draft'];

function evaluateBankSource(source) {
  const sandbox = { window: {} };
  sandbox.self = sandbox.window;
  vm.createContext(sandbox, { codeGeneration: { strings: false, wasm: false } });
  vm.runInContext(String(source), sandbox, { timeout: 1000 });
  return sandbox.window.HEC_QUESTION_BANK;
}

const normText = s => String(s).toLowerCase().replace(/\s+/g, ' ').trim();

/**
 * @param {object} bank  value of window.HEC_QUESTION_BANK
 * @param {{subject:string}} expected  catalogue entry the file belongs to
 * @returns {{questions:object[], errors:string[], warnings:string[], total:number}}
 */
function validateBank(bank, expected) {
  const errors = [];
  const warnings = [];
  const questions = [];

  if (!bank || typeof bank !== 'object' || Array.isArray(bank)) {
    return { questions, errors: ['The file does not define window.HEC_QUESTION_BANK as an object.'], warnings, total: 0 };
  }
  if (bank.subject !== undefined && slugify(bank.subject) !== expected.subject) {
    errors.push(`bank.subject is "${bank.subject}" but this file is for "${expected.subject}". ` +
      'The frontend refuses a bank whose subject does not match.');
  }
  if (bank.subject === undefined) warnings.push(`bank.subject is missing; it should be "${expected.subject}".`);
  if (!Array.isArray(bank.questions)) {
    errors.push('bank.questions must be an array.');
    return { questions, errors, warnings, total: 0 };
  }
  if (errors.length) return { questions, errors, warnings, total: bank.questions.length };

  const seenIds = new Set();
  const seenText = new Map();

  bank.questions.forEach((q, i) => {
    const label = `Question #${i + 1}` + (q && q.id !== undefined ? ` (id ${JSON.stringify(q.id)})` : '');
    const fail = msg => errors.push(`${label}: ${msg}`);

    if (!q || typeof q !== 'object' || Array.isArray(q)) return fail('is not an object.');

    if (q.id === undefined || q.id === null || String(q.id).trim() === '') return fail('has no id.');
    const id = String(q.id).trim();
    if (id.length > 80 || /[\s]/.test(id)) return fail('id must be at most 80 characters with no spaces.');
    if (seenIds.has(id)) return fail(`duplicate id "${id}".`);

    if (typeof q.question !== 'string' || !q.question.trim()) return fail('"question" must be non-empty text.');

    if (!Array.isArray(q.options) || q.options.length < 2) return fail('"options" must be an array of at least 2 choices.');
    if (q.options.length > MAX_OPTIONS) return fail(`"options" can have at most ${MAX_OPTIONS} choices.`);
    if (!q.options.every(o => typeof o === 'string' && o.trim() !== '')) return fail('every option must be non-empty text.');
    const opts = q.options.map(o => normText(o));
    if (new Set(opts).size !== opts.length) return fail('two options have identical text.');

    if (!Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length) {
      return fail(`"answer" must be the position (0-${q.options.length - 1}) of the correct option, not text. ` +
        'If the correct answer is uncertain, leave the question out or set status: "draft".');
    }

    if (q.explanation !== undefined && typeof q.explanation !== 'string') return fail('"explanation" must be text.');
    if (q.topic !== undefined && typeof q.topic !== 'string') return fail('"topic" must be text.');
    const status = q.status === undefined ? 'published' : q.status;
    if (!STATUSES.includes(status)) return fail(`"status" must be one of ${STATUSES.join(', ')}.`);
    if (q.year !== undefined && !(Number.isInteger(q.year) && q.year > 1900 && q.year < 2200) && typeof q.year !== 'string') {
      return fail('"year" must be a year such as 2017 or text such as "2017 E.C.".');
    }

    const key = normText(q.question);
    if (seenText.has(key)) return fail(`has the same question text as ${seenText.get(key)}.`);

    seenIds.add(id);
    seenText.set(key, `question #${i + 1} (id ${id})`);
    if (!q.explanation) warnings.push(`${label}: no explanation.`);

    questions.push({
      qid: id,
      position: questions.length,
      topic: (q.topic || 'General').trim() || 'General',
      question: q.question.trim(),
      options: q.options.map(o => o.trim()),
      answer: q.answer,
      explanation: (q.explanation || '').trim(),
      year: q.year === undefined ? null : String(q.year),
      source: typeof q.source === 'string' ? q.source.trim() : '',
      difficulty: ['easy', 'medium', 'hard'].includes(q.difficulty) ? q.difficulty : null,
      status
    });
  });

  return { questions, errors, warnings, total: bank.questions.length };
}

function parseBankSource(source, expected) {
  let bank;
  try {
    bank = evaluateBankSource(source);
  } catch (err) {
    return { questions: [], errors: [`The file could not be read: ${err.message}`], warnings: [], total: 0 };
  }
  return validateBank(bank, expected);
}

module.exports = { parseBankSource, validateBank, evaluateBankSource };
