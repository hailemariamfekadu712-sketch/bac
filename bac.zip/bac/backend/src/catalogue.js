'use strict';
/*
  Single source of truth for grades, curricula and subjects.
  Mirrors the frontend (grades.js, subjects.js, selection.js, exam-types.js,
  question-loader.js). scripts/check-frontend-parity.js verifies this.
*/

const SUBJECT_NAMES = {
  english: 'English',
  mathematics: 'Mathematics',
  amharic: 'Amharic',
  'afaan-oromo': 'Afaan Oromo',
  'general-science': 'General Science',
  biology: 'Biology',
  chemistry: 'Chemistry',
  physics: 'Physics',
  'social-studies': 'Social Studies',
  citizenship: 'Civics and Ethical Education',
  ict: 'Information and Communication Technology',
  'health-and-physical-education': 'Health and Physical Education',
  art: 'Art Education',
  aptitude: 'General Aptitude',
  geography: 'Geography',
  history: 'History',
  economics: 'Economics'
};

const G6 = ['english', 'mathematics', 'amharic', 'afaan-oromo', 'general-science', 'social-studies',
  'citizenship', 'ict', 'health-and-physical-education', 'art'];
const G8 = ['english', 'mathematics', 'amharic', 'afaan-oromo', 'biology', 'chemistry', 'physics',
  'social-studies', 'citizenship', 'ict', 'health-and-physical-education'];

const SUBJECT_IDS = {
  '6': { amhara: G6, 'addis-ababa': G6 },
  '8': { amhara: G8, 'addis-ababa': G8 },
  '12': {
    natural: ['english', 'mathematics', 'aptitude', 'physics', 'chemistry', 'biology'],
    social: ['english', 'mathematics', 'aptitude', 'geography', 'history', 'economics']
  }
};

const GRADES = {
  '6': { id: '6', label: 'Grade 6', examName: 'Grade 6 Regional Examination', requiresRegion: true, requiresStream: false,
    regions: [{ value: 'amhara', label: 'Amhara Region' }, { value: 'addis-ababa', label: 'Addis Ababa City Administration' }], streams: [] },
  '8': { id: '8', label: 'Grade 8', examName: 'Grade 8 Regional Examination', requiresRegion: true, requiresStream: false,
    regions: [{ value: 'amhara', label: 'Amhara Region' }, { value: 'addis-ababa', label: 'Addis Ababa City Administration' }], streams: [] },
  '12': { id: '12', label: 'Grade 12', examName: 'Ethiopian University Entrance Examination', requiresRegion: false, requiresStream: true,
    regions: [], streams: [{ value: 'natural', label: 'Natural Science' }, { value: 'social', label: 'Social Science' }] }
};

const EXAM_MODES = [
  { id: 'practice', title: 'Practice' },
  { id: 'mock', title: 'Mock Examination' }
];

/* ---------- normalisation (same rules as selection.js / subjects.js) ---------- */

function normalizeGrade(g) { return String(g == null ? '' : g).trim(); }

function normalizeRegion(r) {
  const v = String(r || '').trim().toLowerCase().replace(/_/g, '-').replace(/\s+/g, '-');
  if (v === 'addis' || v === 'addisababa' || v === 'addis-ababa-city-administration') return 'addis-ababa';
  if (v === 'amhara' || v === 'amhara-region') return 'amhara';
  return v;
}

function normalizeStream(s) {
  const v = String(s || '').trim().toLowerCase().replace(/\s+/g, '-');
  if (v === 'natural' || v === 'natural-science') return 'natural';
  if (v === 'social' || v === 'social-science' || v === 'social-sciences') return 'social';
  return v;
}

function slugify(value) {
  return String(value || '').trim().toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

/* ---------- lookups ---------- */

/** Returns { ok, grade, region, stream, curriculum } or { ok:false, message } */
function resolveCurriculum({ grade, region, stream } = {}) {
  const g = normalizeGrade(grade);
  if (!GRADES[g]) return { ok: false, message: 'Choose Grade 6, Grade 8, or Grade 12.' };
  if (g === '12') {
    const st = normalizeStream(stream);
    if (!SUBJECT_IDS['12'][st]) return { ok: false, message: 'Choose Natural Science or Social Science.' };
    return { ok: true, grade: g, region: '', stream: st, curriculum: st };
  }
  const rg = normalizeRegion(region);
  if (!SUBJECT_IDS[g][rg]) return { ok: false, message: 'Choose Amhara or Addis Ababa.' };
  return { ok: true, grade: g, region: rg, stream: '', curriculum: rg };
}

function getSubjects(sel) {
  const c = resolveCurriculum(sel);
  if (!c.ok) return [];
  return SUBJECT_IDS[c.grade][c.curriculum].map(id => ({ id, name: SUBJECT_NAMES[id] }));
}

function getSubject(sel, subjectId) {
  const id = slugify(subjectId);
  return getSubjects(sel).find(s => s.id === id) || null;
}

/* ---------- question-bank keys (same file naming as question-loader.js) ---------- */

function fileRegion(curriculum) { return curriculum === 'addis-ababa' ? 'addis' : curriculum; }

function bankKey(sel, subjectId) {
  const c = resolveCurriculum(sel);
  if (!c.ok) return null;
  const subj = getSubject(c, subjectId);
  if (!subj) return null;
  return `grade${c.grade}-${fileRegion(c.curriculum)}-${subj.id}`;
}

function bankFilename(sel, subjectId) {
  const k = bankKey(sel, subjectId);
  return k ? `${k}.js` : null;
}

/** Every bank the catalogue expects: [{ key, filename, grade, region, stream, subject, subjectTitle }] */
function allBanks() {
  const out = [];
  for (const g of Object.keys(SUBJECT_IDS)) {
    for (const cur of Object.keys(SUBJECT_IDS[g])) {
      for (const id of SUBJECT_IDS[g][cur]) {
        const key = `grade${g}-${fileRegion(cur)}-${id}`;
        out.push({
          key, filename: key + '.js', grade: g,
          region: g === '12' ? '' : cur, stream: g === '12' ? cur : '',
          subject: id, subjectTitle: SUBJECT_NAMES[id]
        });
      }
    }
  }
  return out;
}

const BANKS_BY_KEY = new Map(allBanks().map(b => [b.key, b]));
function getBank(key) { return BANKS_BY_KEY.get(key) || null; }

/*
  Older blank placeholder files used slightly different subject names.
  Only unambiguous ones are mapped; anything else is reported, never guessed.
*/
const LEGACY_SUBJECT_ALIASES = {
  'citizenship-education': 'citizenship',
  'information-technology': 'ict',
  'physical-education': 'health-and-physical-education'
};

/** Map a file name like grade6-addis-citizenship-education.js to a catalogue bank. */
function resolveBankFilename(filename) {
  const m = /^grade(6|8|12)-(amhara|addis|natural|social)-(.+)\.js$/.exec(filename);
  if (!m) return { ok: false, reason: 'not-a-bank-file' };
  const key = filename.replace(/\.js$/, '');
  if (BANKS_BY_KEY.has(key)) return { ok: true, bank: BANKS_BY_KEY.get(key), alias: false };
  const aliasSubject = LEGACY_SUBJECT_ALIASES[m[3]];
  if (aliasSubject) {
    const k2 = `grade${m[1]}-${m[2]}-${aliasSubject}`;
    if (BANKS_BY_KEY.has(k2)) return { ok: true, bank: BANKS_BY_KEY.get(k2), alias: true };
  }
  return { ok: false, reason: 'unknown-subject' };
}

module.exports = {
  GRADES, EXAM_MODES, SUBJECT_NAMES, SUBJECT_IDS, LEGACY_SUBJECT_ALIASES,
  normalizeGrade, normalizeRegion, normalizeStream, slugify,
  resolveCurriculum, getSubjects, getSubject, bankKey, bankFilename, allBanks, getBank, resolveBankFilename
};
