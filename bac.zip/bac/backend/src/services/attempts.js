'use strict';
const { bad, notFound, HttpError } = require('../lib/http');
const { newId } = require('../lib/security');
const catalogue = require('../catalogue');

const EXAM_TYPES = ['practice', 'mock'];

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

const isoNow = () => new Date().toISOString();
const remaining = a => Math.max(0, Math.ceil((Date.parse(a.deadline) - Date.now()) / 1000));

/** Grade an attempt on the server. Never trusts a score from the client. */
function gradeAttempt(a) {
  let correct = 0, incorrect = 0, unanswered = 0;
  const review = a.questions.map(q => {
    const has = Object.prototype.hasOwnProperty.call(a.answers, q.qid);
    const selected = has ? a.answers[q.qid] : null;
    let status = 'unanswered';
    if (has && selected === q.answer) { correct++; status = 'correct'; }
    else if (has) { incorrect++; status = 'incorrect'; }
    else unanswered++;
    return {
      id: q.qid, questionId: q.qid, topic: q.topic, question: q.question, options: q.options,
      selectedAnswer: selected, correctAnswer: q.answer, isCorrect: status === 'correct', status,
      explanation: q.explanation, markedForReview: Boolean(a.marked[q.qid])
    };
  });
  const total = a.questions.length;
  return { total, correct, incorrect, unanswered, percentage: total ? Math.round((correct / total) * 100) : 0, review };
}

/** The shape the frontend already stores in user.examHistory (plus both field-name variants it uses). */
function attemptView(a, { detail = true } = {}) {
  const base = {
    id: a.id, subject: a.subject, subjectTitle: a.subjectTitle, grade: a.grade, region: a.region, stream: a.stream,
    examType: a.examType, status: a.status, startedAt: a.startedAt, durationSeconds: a.durationSeconds,
    totalQuestions: a.questions.length
  };
  if (a.status === 'in_progress') {
    const answered = Object.keys(a.answers).length;
    return {
      ...base, deadline: a.deadline, remainingSeconds: remaining(a), answeredCount: answered,
      answers: a.answers, marked: a.marked, currentIndex: a.currentIndex,
      ...(detail ? { questions: a.questions.map(q => ({ id: q.qid, topic: q.topic, question: q.question, options: q.options })) } : {})
    };
  }
  const r = a.result;
  const out = {
    ...base, completedAt: a.completedAt, timeSpentSeconds: r.timeSpentSeconds, timedOut: r.timedOut,
    correct: r.correct, correctAnswers: r.correct, incorrect: r.incorrect, unanswered: r.unanswered,
    score: r.correct, total: r.total, percentage: r.percentage, submissionReason: r.timedOut ? 'time-expired' : 'manual'
  };
  if (detail) { out.answers = a.answers; out.review = r.review; out.questions = r.review; }
  return out;
}

function createAttemptService({ store, config }) {
  async function owned(user, id) {
    const a = await store.getAttempt(id);
    if (!a || a.userId !== user.id) throw notFound('Exam attempt not found.');   // same answer for "not yours"
    return a;
  }

  function checkAnswers(a, map, { allowNull }) {
    if (map === undefined) return {};
    if (!map || typeof map !== 'object' || Array.isArray(map)) throw bad('"answers" must be an object of questionId: optionIndex.');
    const byId = new Map(a.questions.map(q => [q.qid, q]));
    const clean = {};
    for (const [qid, val] of Object.entries(map)) {
      const q = byId.get(qid);
      if (!q) throw bad(`Unknown question id "${qid}" for this attempt.`);
      if (val === null && allowNull) { clean[qid] = null; continue; }
      if (!Number.isInteger(val) || val < 0 || val >= q.options.length) throw bad(`Invalid choice for question "${qid}".`);
      clean[qid] = val;
    }
    return clean;
  }

  function applyAnswers(a, clean) {
    for (const [qid, val] of Object.entries(clean)) { if (val === null) delete a.answers[qid]; else a.answers[qid] = val; }
  }

  return {
    attemptView,

    async start(user, body) {
      const c = catalogue.resolveCurriculum(body);
      if (!c.ok) throw bad(c.message);
      const subj = catalogue.getSubject(c, body.subject);
      if (!subj) throw bad('This subject does not match the selected grade and curriculum.');
      const examType = body.examType === undefined ? 'practice' : String(body.examType);
      if (!EXAM_TYPES.includes(examType)) throw bad('examType must be "practice" or "mock".');

      let minutes = body.durationMinutes === undefined
        ? (examType === 'mock' ? config.exam.defaultMockMinutes : config.exam.defaultPracticeMinutes) : Number(body.durationMinutes);
      if (!Number.isFinite(minutes) || minutes < 1) throw bad('durationMinutes must be a positive number.');
      minutes = Math.min(minutes, config.exam.maxMinutes);

      const key = catalogue.bankKey(c, subj.id);
      let qs = await store.getBankQuestions(key, { publishedOnly: true });
      if (!qs.length) {
        throw new HttpError(404, 'QUESTIONS_NOT_AVAILABLE', `Questions for ${subj.name} are coming soon.`);
      }
      if (body.shuffle === true) qs = shuffle(qs);
      if (body.questionCount !== undefined) {
        const n = Number(body.questionCount);
        if (!Number.isInteger(n) || n < 1) throw bad('questionCount must be a positive whole number.');
        qs = qs.slice(0, n);
      }

      const started = Date.now();
      const attempt = {
        id: newId('attempt'), userId: user.id, bankKey: key,
        grade: c.grade, region: c.region, stream: c.stream, subject: subj.id, subjectTitle: subj.name,
        examType, status: 'in_progress', startedAt: new Date(started).toISOString(),
        durationSeconds: Math.round(minutes * 60), deadline: new Date(started + minutes * 60000).toISOString(),
        questions: qs.map(q => ({ qid: q.qid, topic: q.topic, question: q.question, options: q.options, answer: q.answer, explanation: q.explanation })),
        answers: {}, marked: {}, currentIndex: 0, result: null, completedAt: null
      };
      await store.createAttempt(attempt);
      return { status: 201, json: attemptView(attempt) };
    },

    async get(user, id) {
      const a = await owned(user, id);
      return attemptView(a);
    },

    async list(user, query) {
      let items = await store.listAttempts(user.id, { status: query.status === 'in_progress' || query.status === 'submitted' ? query.status : undefined });
      if (query.subject) items = items.filter(a => a.subject === catalogue.slugify(query.subject));
      if (query.grade) items = items.filter(a => a.grade === catalogue.normalizeGrade(query.grade));
      const limit = Math.min(Math.max(parseInt(query.limit, 10) || 100, 1), 500);
      const offset = Math.max(parseInt(query.offset, 10) || 0, 0);
      return { total: items.length, attempts: items.slice(offset, offset + limit).map(a => attemptView(a, { detail: false })) };
    },

    async saveAnswers(user, id, body) {
      const a = await owned(user, id);
      if (a.status !== 'in_progress') throw new HttpError(409, 'ALREADY_SUBMITTED', 'This exam has already been submitted.');
      if (Date.now() > Date.parse(a.deadline) + config.exam.submitGraceSeconds * 1000) {
        throw new HttpError(409, 'TIME_EXPIRED', 'Time is up for this exam. Submit it to see your result.');
      }
      applyAnswers(a, checkAnswers(a, body.answers, { allowNull: true }));
      if (body.marked !== undefined) {
        if (!body.marked || typeof body.marked !== 'object' || Array.isArray(body.marked)) throw bad('"marked" must be an object.');
        const ids = new Set(a.questions.map(q => q.qid));
        a.marked = {};
        for (const [qid, v] of Object.entries(body.marked)) if (v && ids.has(qid)) a.marked[qid] = true;
      }
      if (body.currentIndex !== undefined) {
        if (!Number.isInteger(body.currentIndex) || body.currentIndex < 0 || body.currentIndex >= a.questions.length) throw bad('currentIndex is out of range.');
        a.currentIndex = body.currentIndex;
      }
      await store.saveAttempt(a);
      return { saved: Object.keys(a.answers).length, remainingSeconds: remaining(a) };
    },

    async submit(user, id, body) {
      const a = await owned(user, id);
      if (a.status === 'submitted') return attemptView(a);        // idempotent: a repeat submit never re-grades

      const now = Date.now();
      const late = now > Date.parse(a.deadline) + config.exam.submitGraceSeconds * 1000;
      if (!late) applyAnswers(a, checkAnswers(a, body.answers, { allowNull: true }));   // final answers sent with the submit

      const g = gradeAttempt(a);
      const spent = Math.min(a.durationSeconds, Math.max(0, Math.round((now - Date.parse(a.startedAt)) / 1000)));
      a.result = {
        total: g.total, correct: g.correct, incorrect: g.incorrect, unanswered: g.unanswered, percentage: g.percentage,
        timeSpentSeconds: spent, timedOut: now > Date.parse(a.deadline), review: g.review
      };
      a.status = 'submitted';
      a.completedAt = new Date(now).toISOString();
      await store.saveAttempt(a);
      return attemptView(a);
    },

    async result(user, id) {
      const a = await owned(user, id);
      if (a.status !== 'submitted') throw new HttpError(409, 'NOT_SUBMITTED', 'This exam has not been submitted yet.');
      return attemptView(a);
    },

    async progress(user) {
      const done = (await store.listAttempts(user.id, { status: 'submitted' })).filter(a => a.result);
      const subjects = new Map();
      const topics = new Map();
      let sumPct = 0, best = 0, seconds = 0, answeredTotal = 0, correctTotal = 0;

      for (const a of done) {
        const r = a.result;
        sumPct += r.percentage; best = Math.max(best, r.percentage); seconds += r.timeSpentSeconds;
        answeredTotal += r.total; correctTotal += r.correct;
        const sk = `${a.grade}|${a.region}|${a.stream}|${a.subject}`;
        const s = subjects.get(sk) || { grade: a.grade, region: a.region, stream: a.stream, subject: a.subject, subjectTitle: a.subjectTitle,
          attempts: 0, sumPct: 0, best: 0, lastPercentage: 0, lastAt: '' };
        s.attempts++; s.sumPct += r.percentage; s.best = Math.max(s.best, r.percentage);
        if (a.completedAt > s.lastAt) { s.lastAt = a.completedAt; s.lastPercentage = r.percentage; }
        subjects.set(sk, s);
        for (const item of r.review) {
          if (item.status === 'unanswered') continue;
          const tk = `${sk}|${item.topic}`;
          const t = topics.get(tk) || { subject: a.subject, subjectTitle: a.subjectTitle, grade: a.grade, topic: item.topic, answered: 0, correct: 0 };
          t.answered++; if (item.isCorrect) t.correct++;
          topics.set(tk, t);
        }
      }
      const chrono = done.slice().sort((x, y) => (x.completedAt > y.completedAt ? 1 : -1));
      return {
        totalAttempts: done.length,
        averagePercentage: done.length ? Math.round(sumPct / done.length) : 0,
        bestPercentage: best,
        questionsAnswered: answeredTotal,
        overallAccuracy: answeredTotal ? Math.round((correctTotal / answeredTotal) * 100) : 0,
        totalTimeSeconds: seconds,
        bySubject: [...subjects.values()].map(s => ({ ...s, averagePercentage: Math.round(s.sumPct / s.attempts), sumPct: undefined }))
          .sort((x, y) => (y.lastAt > x.lastAt ? 1 : -1)),
        byTopic: [...topics.values()].map(t => ({ ...t, accuracy: Math.round((t.correct / t.answered) * 100) }))
          .sort((x, y) => x.accuracy - y.accuracy),
        recent: chrono.slice(-20).map(a => ({ id: a.id, subject: a.subject, subjectTitle: a.subjectTitle, examType: a.examType,
          percentage: a.result.percentage, completedAt: a.completedAt }))
      };
    }
  };
}

module.exports = { createAttemptService, gradeAttempt, attemptView };
