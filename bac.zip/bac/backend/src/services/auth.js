'use strict';
const { hashPassword, verifyPassword, signToken, verifyToken, newId } = require('../lib/security');
const { bad, conflict, HttpError } = require('../lib/http');
const catalogue = require('../catalogue');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function publicUser(u) {
  return {
    id: u.id, fullName: u.fullName, email: u.email, grade: u.grade || '', region: u.region || '', stream: u.stream || '',
    role: u.role, createdAt: u.createdAt, preferences: u.preferences || {}
  };
}

function createAuthService({ store, config }) {
  const issue = user => signToken({ sub: user.id, role: user.role }, config.jwtSecret, config.jwtTtlSeconds);

  function checkPassword(p) {
    if (typeof p !== 'string' || p.length < 8) throw bad('Password must be at least 8 characters.');
    if (p.length > 200) throw bad('Password is too long.');
  }

  return {
    publicUser,

    async register(body) {
      const fullName = String(body.fullName || '').trim();
      const email = String(body.email || '').trim().toLowerCase();
      const grade = catalogue.normalizeGrade(body.grade);
      if (fullName.length < 2 || fullName.length > 100) throw bad('Enter your full name (2-100 characters).');
      if (!EMAIL_RE.test(email) || email.length > 200) throw bad('Enter a valid email address.');
      checkPassword(body.password);
      if (grade && !catalogue.GRADES[grade]) throw bad('Grade must be 6, 8 or 12.');

      const user = {
        id: newId('hec'), fullName, email, passwordHash: await hashPassword(body.password), role: 'student',
        grade, region: '', stream: '', preferences: { theme: 'light' }, studyPlan: [], flashcards: [],
        createdAt: new Date().toISOString()
      };
      try { await store.createUser(user); }
      catch (e) {
        if (e.code === 'DUPLICATE_EMAIL') throw conflict('An account with this email already exists. Please log in instead.', 'EMAIL_TAKEN');
        throw e;
      }
      return { token: issue(user), user: publicUser(user) };
    },

    async login(body) {
      const user = await store.getUserByEmail(body.email);
      // Same error for unknown email and wrong password.
      const ok = user ? await verifyPassword(body.password, user.passwordHash) : false;
      if (!ok) throw new HttpError(401, 'INVALID_CREDENTIALS', 'We could not find a matching account. Check your details or register first.');
      return { token: issue(user), user: publicUser(user) };
    },

    async authenticate(req) {
      const header = req.headers.authorization || '';
      const m = /^Bearer (.+)$/.exec(header);
      if (!m) return null;
      const payload = verifyToken(m[1], config.jwtSecret);
      if (!payload) return null;
      return (await store.getUserById(payload.sub)) || null;
    },

    async changePassword(user, body) {
      if (!(await verifyPassword(body.currentPassword, user.passwordHash))) throw bad('Your current password is incorrect.');
      checkPassword(body.newPassword);
      if (body.newPassword === body.currentPassword) throw bad('Choose a new password that is different from the current one.');
      await store.updateUser(user.id, { passwordHash: await hashPassword(body.newPassword) });
      return { ok: true };
    }
  };
}

module.exports = { createAuthService, publicUser };
