'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { bad, notFound } = require('../lib/http');
const catalogue = require('../catalogue');
const { parseBankSource, validateBank } = require('../bank-parser');

const slug = v => String(v || '').trim().toLowerCase();
const ID_RE = /^[a-z0-9][a-z0-9-_]{0,79}$/;

function createContentService({ store, config }) {
  const readSeed = name => {
    try { return JSON.parse(fs.readFileSync(path.join(config.contentDir, name), 'utf8')); } catch { return []; }
  };

  return {
    /** Insert the frontend's original resources/announcements the first time only. */
    async seed() {
      if (!(await store.listResources()).length) for (const r of readSeed('resources.json')) await store.upsertResource(r);
      if (!(await store.listAnnouncements()).length) for (const a of readSeed('announcements.json')) await store.upsertAnnouncement(a);
    },

    /* ---- catalogue ---- */
    grades() { return { grades: Object.values(catalogue.GRADES) }; },

    examTypes(grade) {
      const g = catalogue.GRADES[catalogue.normalizeGrade(grade)];
      if (!g) throw bad('Choose Grade 6, Grade 8, or Grade 12.');
      return { grade: g.id, examName: g.examName, modes: catalogue.EXAM_MODES };
    },

    async subjects(query) {
      const c = catalogue.resolveCurriculum(query);
      if (!c.ok) throw bad(c.message);
      const counts = await store.bankCounts();
      return {
        grade: c.grade, region: c.region, stream: c.stream, examName: catalogue.GRADES[c.grade].examName,
        subjects: catalogue.getSubjects(c).map(s => {
          const n = counts[catalogue.bankKey(c, s.id)] || 0;
          return { ...s, questionCount: n, available: n > 0 };
        })
      };
    },

    /** Questions WITHOUT answers or explanations (answers only come back after grading). */
    async questions(query) {
      const c = catalogue.resolveCurriculum(query);
      if (!c.ok) throw bad(c.message);
      const subj = catalogue.getSubject(c, query.subject);
      if (!subj) throw bad('This subject does not match the selected grade and curriculum.');
      const qs = await store.getBankQuestions(catalogue.bankKey(c, subj.id));
      return {
        grade: c.grade, region: c.region, stream: c.stream, subject: subj.id, subjectTitle: subj.name, total: qs.length,
        questions: qs.map(q => ({ id: q.qid, topic: q.topic, question: q.question, options: q.options }))
      };
    },

    /* ---- resources / announcements ---- */
    async resources(query) {
      let items = await store.listResources();
      if (query.grade) { const g = catalogue.normalizeGrade(query.grade); items = items.filter(r => r.grade === 'all' || String(r.grade) === g); }
      if (query.subject) items = items.filter(r => r.subject === slug(query.subject));
      if (query.type) items = items.filter(r => r.type === slug(query.type));
      return { resources: items };
    },
    async resource(id) {
      const r = (await store.listResources()).find(x => x.id === id);
      if (!r) throw notFound('Resource not found.');
      return r;
    },
    async announcements() {
      const items = (await store.listAnnouncements()).filter(a => a.status === 'published');
      items.sort((a, b) => (a.priority - b.priority) || (a.date < b.date ? 1 : -1));
      return { announcements: items };
    },

    /* ---- admin ---- */
    async adminUpsertAnnouncement(id, body) {
      if (!ID_RE.test(id)) throw bad('Id may contain only a-z, 0-9, "-" and "_".');
      const title = String(body.title || '').trim(); const message = String(body.message || '').trim();
      if (!title || !message) throw bad('Title and message are required.');
      const date = String(body.date || new Date().toISOString().slice(0, 10));
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw bad('date must be YYYY-MM-DD.');
      const status = body.status === 'draft' ? 'draft' : 'published';
      return store.upsertAnnouncement({ id, title, message, category: String(body.category || 'general'), date, status, priority: Number(body.priority) || 1 });
    },
    async adminUpsertResource(id, body) {
      if (!ID_RE.test(id)) throw bad('Id may contain only a-z, 0-9, "-" and "_".');
      const title = String(body.title || '').trim();
      if (!title) throw bad('Title is required.');
      const url = String(body.url || '').trim();
      if (url && !/^https?:\/\//i.test(url)) throw bad('url must start with http:// or https://');
      const status = url ? (body.status === 'coming-soon' ? 'coming-soon' : 'available') : 'coming-soon';
      return store.upsertResource({
        id, title, description: String(body.description || ''), grade: String(body.grade || 'all'),
        subject: slug(body.subject), type: slug(body.type) || 'short-note', url, status
      });
    },

    /**
     * Upload questions for one subject. All-or-nothing: if any question is invalid
     * nothing is saved and every problem is returned.
     */
    async adminUploadQuestions(body) {
      const c = catalogue.resolveCurriculum(body);
      if (!c.ok) throw bad(c.message);
      const subj = catalogue.getSubject(c, body.subject);
      if (!subj) throw bad('This subject does not match the selected grade and curriculum.');
      if (!Array.isArray(body.questions)) throw bad('"questions" must be an array.');
      const mode = body.mode === 'append' ? 'append' : 'replace';
      const key = catalogue.bankKey(c, subj.id);
      const bank = catalogue.getBank(key);

      let raw = body.questions;
      if (mode === 'append') {
        const existing = await store.getBankQuestions(key, { publishedOnly: false });
        raw = existing.map(q => ({ id: q.qid, topic: q.topic, question: q.question, options: q.options, answer: q.answer,
          explanation: q.explanation, year: q.year === null ? undefined : q.year, source: q.source, difficulty: q.difficulty || undefined,
          status: q.status })).concat(body.questions);
      }
      const parsed = validateBank({ subject: subj.id, questions: raw }, bank);
      if (parsed.errors.length) {
        const e = bad(`${parsed.errors.length} problem(s) found. Nothing was saved.`, { errors: parsed.errors });
        throw e;
      }
      await store.replaceBank(key, { grade: bank.grade, region: bank.region, stream: bank.stream, subject: bank.subject, subjectTitle: bank.subjectTitle }, parsed.questions);
      return { bank: key, mode, saved: parsed.questions.length, published: parsed.questions.filter(q => q.status === 'published').length, warnings: parsed.warnings };
    },

    async adminQuestionReport() {
      const counts = await store.bankCounts();
      const banks = catalogue.allBanks().map(b => ({ key: b.key, file: b.filename, grade: b.grade, region: b.region, stream: b.stream,
        subject: b.subject, subjectTitle: b.subjectTitle, published: counts[b.key] || 0 }));
      return { banks, banksWithQuestions: banks.filter(b => b.published > 0).length, banksExpected: banks.length,
        totalPublished: banks.reduce((n, b) => n + b.published, 0) };
    }
  };
}

module.exports = { createContentService, parseBankSource };
