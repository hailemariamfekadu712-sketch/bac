'use strict';
const config = require('./config');
const { createStore } = require('./store');
const { createApp } = require('./app');
const { importBanks } = require('./importer');

async function main() {
  const store = createStore();
  await store.init();

  const { server, content } = createApp({ store, config });
  await content.seed();

  if (config.importOnStart) {
    const report = await importBanks(store, config.bankDir);
    console.log(`[questions] ${report.totals.published} published question(s) in ${report.banksWithQuestions}/${report.banksExpected} subject banks.`);
    for (const f of report.files) for (const e of f.errors) console.warn(`[questions] ${f.file}: ${e}`);
    for (const u of report.unknown) console.warn(`[questions] ${u.file}: ${u.reason}`);
  }

  server.listen(config.port, () => console.log(`[hec] API on http://localhost:${config.port}/api/v1  (store: ${store.kind})`));

  const stop = async () => { server.close(); await store.close(); process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

main().catch(err => { console.error('[hec] failed to start:', err); process.exit(1); });
