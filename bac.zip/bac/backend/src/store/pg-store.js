'use strict';
/*
  PostgreSQL store. Same interface as memory-store.js.
  Schema: database/migrations/001_init.sql (run `npm run migrate`).
*/
class PgStore {
  constructor({ connectionString }) {
    this.kind = 'postgres';
    this.connectionString = connectionString;
    this.pool = null;
  }

  async init() {
    const { Pool } = require('pg'); // required lazily so the dev store needs no packages
    const ssl = /sslmode=disable/.test(this.connectionString) || /localhost|127\.0\.0\.1/.test(this.connectionString)
      ? undefined : { rejectUnauthorized: false };
    this.pool = new Pool({ connectionString: this.connectionString, ssl, max: 10 });
    await this.pool.query('SELECT 1');
  }
  async close() { if (this.pool) await this.pool.end(); }
  q(text, params) { return this.pool.query(text, params); }

  /* ---- users ---- */
  _user(r) {
    if (!r) return null;
    return {
      id: r.id, email: r.email, fullName: r.full_name, passwordHash: r.password_hash, role: r.role,
      grade: r.grade, region: r.region, stream: r.stream, preferences: r.preferences,
      studyPlan: r.study_plan, flashcards: r.flashcards, createdAt: r.created_at.toISOString()
    };
  }
  async createUser(u) {
    try {
      const { rows } = await this.q(
        `INSERT INTO users (id,email,full_name,password_hash,role,grade,region,stream,preferences,study_plan,flashcards,created_at)
         VALUES ($1,lower($2),$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
        [u.id, u.email, u.fullName, u.passwordHash, u.role, u.grade, u.region, u.stream,
          JSON.stringify(u.preferences || {}), JSON.stringify(u.studyPlan || []), JSON.stringify(u.flashcards || []), u.createdAt]);
      return this._user(rows[0]);
    } catch (e) {
      if (e.code === '23505') { const err = new Error('duplicate email'); err.code = 'DUPLICATE_EMAIL'; throw err; }
      throw e;
    }
  }
  async getUserById(id) { return this._user((await this.q('SELECT * FROM users WHERE id=$1', [id])).rows[0]); }
  async getUserByEmail(email) {
    return this._user((await this.q('SELECT * FROM users WHERE email=lower($1)', [String(email || '').trim()])).rows[0]);
  }
  async updateUser(id, patch) {
    const map = { fullName: 'full_name', passwordHash: 'password_hash', role: 'role', grade: 'grade', region: 'region',
      stream: 'stream', preferences: 'preferences', studyPlan: 'study_plan', flashcards: 'flashcards' };
    const jsonCols = new Set(['preferences', 'study_plan', 'flashcards']);
    const sets = []; const vals = [];
    for (const [k, v] of Object.entries(patch)) {
      if (!map[k]) continue;
      vals.push(jsonCols.has(map[k]) ? JSON.stringify(v) : v);
      sets.push(`${map[k]}=$${vals.length}`);
    }
    if (!sets.length) return this.getUserById(id);
    vals.push(id);
    return this._user((await this.q(`UPDATE users SET ${sets.join(',')} WHERE id=$${vals.length} RETURNING *`, vals)).rows[0]);
  }

  /* ---- question banks ---- */
  async replaceBank(key, meta, questions) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `INSERT INTO question_banks (key,grade,region,stream,subject,subject_title,updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,now())
         ON CONFLICT (key) DO UPDATE SET grade=$2,region=$3,stream=$4,subject=$5,subject_title=$6,updated_at=now()`,
        [key, meta.grade, meta.region, meta.stream, meta.subject, meta.subjectTitle]);
      await client.query('DELETE FROM questions WHERE bank_key=$1', [key]);
      for (const q of questions) {
        await client.query(
          `INSERT INTO questions (bank_key,qid,position,topic,question,options,answer,explanation,year,source,difficulty,status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
          [key, q.qid, q.position, q.topic, q.question, JSON.stringify(q.options), q.answer, q.explanation,
            q.year, q.source, q.difficulty, q.status]);
      }
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  }
  async getBankQuestions(key, { publishedOnly = true } = {}) {
    const { rows } = await this.q(
      `SELECT * FROM questions WHERE bank_key=$1 ${publishedOnly ? "AND status='published'" : ''} ORDER BY position`, [key]);
    return rows.map(r => ({ qid: r.qid, position: r.position, topic: r.topic, question: r.question, options: r.options,
      answer: r.answer, explanation: r.explanation, year: r.year, source: r.source, difficulty: r.difficulty, status: r.status }));
  }
  async bankCounts() {
    const { rows } = await this.q(`SELECT bank_key, count(*)::int AS n FROM questions WHERE status='published' GROUP BY bank_key`);
    return Object.fromEntries(rows.map(r => [r.bank_key, r.n]));
  }

  /* ---- attempts (whole object kept in JSONB) ---- */
  async createAttempt(a) {
    await this.q('INSERT INTO attempts (id,user_id,bank_key,status,started_at,data) VALUES ($1,$2,$3,$4,$5,$6)',
      [a.id, a.userId, a.bankKey, a.status, a.startedAt, JSON.stringify(a)]);
    return a;
  }
  async getAttempt(id) { const r = (await this.q('SELECT data FROM attempts WHERE id=$1', [id])).rows[0]; return r ? r.data : null; }
  async saveAttempt(a) {
    await this.q('UPDATE attempts SET status=$2, completed_at=$3, data=$4 WHERE id=$1',
      [a.id, a.status, a.completedAt || null, JSON.stringify(a)]);
    return a;
  }
  async listAttempts(userId, { status } = {}) {
    const { rows } = await this.q(
      `SELECT data FROM attempts WHERE user_id=$1 ${status ? 'AND status=$2' : ''} ORDER BY started_at DESC`,
      status ? [userId, status] : [userId]);
    return rows.map(r => r.data);
  }

  /* ---- content ---- */
  async listResources() { return (await this.q('SELECT data FROM resources')).rows.map(r => r.data); }
  async upsertResource(r) {
    await this.q('INSERT INTO resources (id,data) VALUES ($1,$2) ON CONFLICT (id) DO UPDATE SET data=$2', [r.id, JSON.stringify(r)]);
    return r;
  }
  async deleteResource(id) { return (await this.q('DELETE FROM resources WHERE id=$1', [id])).rowCount > 0; }
  async listAnnouncements() { return (await this.q('SELECT data FROM announcements')).rows.map(r => r.data); }
  async upsertAnnouncement(a) {
    await this.q('INSERT INTO announcements (id,data) VALUES ($1,$2) ON CONFLICT (id) DO UPDATE SET data=$2', [a.id, JSON.stringify(a)]);
    return a;
  }
  async deleteAnnouncement(id) { return (await this.q('DELETE FROM announcements WHERE id=$1', [id])).rowCount > 0; }

  async addAudit(e) {
    await this.q('INSERT INTO audit_logs (at,actor_id,action,detail) VALUES ($1,$2,$3,$4)',
      [e.at, e.actorId || null, e.action, JSON.stringify(e.detail || {})]);
  }
}

module.exports = { PgStore };
