'use strict';
/*
  Development store: everything in memory, optionally saved to one JSON file.
  Same interface as pg-store.js. Not for production use.
*/
const fs = require('node:fs');
const path = require('node:path');

const clone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));

class MemoryStore {
  constructor({ file = null } = {}) {
    this.kind = file ? 'json-file' : 'memory';
    this.file = file;
    this.db = { users: {}, banks: {}, attempts: {}, resources: {}, announcements: {}, audit: [] };
    this._timer = null;
  }

  async init() {
    if (this.file && fs.existsSync(this.file)) {
      try { this.db = { ...this.db, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) }; }
      catch (e) { console.warn('[store] could not read', this.file, '- starting empty:', e.message); }
    }
  }

  _save() {
    if (!this.file) return;
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.flush(), 150);
    this._timer.unref();
  }

  flush() {
    if (!this.file) return;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.db));
    fs.renameSync(tmp, this.file);
  }

  async close() { clearTimeout(this._timer); this.flush(); }

  /* ---- users ---- */
  async createUser(user) {
    const email = user.email.toLowerCase();
    if (Object.values(this.db.users).some(u => u.email === email)) {
      const e = new Error('duplicate email'); e.code = 'DUPLICATE_EMAIL'; throw e;
    }
    this.db.users[user.id] = clone({ ...user, email });
    this._save();
    return clone(this.db.users[user.id]);
  }
  async getUserById(id) { return clone(this.db.users[id]) || null; }
  async getUserByEmail(email) {
    const e = String(email || '').trim().toLowerCase();
    return clone(Object.values(this.db.users).find(u => u.email === e)) || null;
  }
  async updateUser(id, patch) {
    const u = this.db.users[id];
    if (!u) return null;
    Object.assign(u, clone(patch));
    this._save();
    return clone(u);
  }

  /* ---- question banks ---- */
  async replaceBank(key, meta, questions) {
    this.db.banks[key] = { meta: clone(meta), questions: clone(questions), updatedAt: new Date().toISOString() };
    this._save();
  }
  async getBankQuestions(key, { publishedOnly = true } = {}) {
    const bank = this.db.banks[key];
    if (!bank) return [];
    return clone(bank.questions.filter(q => !publishedOnly || q.status === 'published'));
  }
  async bankCounts() {
    const out = {};
    for (const [k, b] of Object.entries(this.db.banks)) out[k] = b.questions.filter(q => q.status === 'published').length;
    return out;
  }

  /* ---- attempts ---- */
  async createAttempt(a) { this.db.attempts[a.id] = clone(a); this._save(); return clone(a); }
  async getAttempt(id) { return clone(this.db.attempts[id]) || null; }
  async saveAttempt(a) { this.db.attempts[a.id] = clone(a); this._save(); return clone(a); }
  async listAttempts(userId, { status } = {}) {
    return clone(Object.values(this.db.attempts)
      .filter(a => a.userId === userId && (!status || a.status === status))
      .sort((x, y) => (y.startedAt > x.startedAt ? 1 : -1)));
  }

  /* ---- content ---- */
  async listResources() { return clone(Object.values(this.db.resources)); }
  async upsertResource(r) { this.db.resources[r.id] = clone(r); this._save(); return clone(r); }
  async deleteResource(id) { const had = id in this.db.resources; delete this.db.resources[id]; this._save(); return had; }
  async listAnnouncements() { return clone(Object.values(this.db.announcements)); }
  async upsertAnnouncement(a) { this.db.announcements[a.id] = clone(a); this._save(); return clone(a); }
  async deleteAnnouncement(id) { const had = id in this.db.announcements; delete this.db.announcements[id]; this._save(); return had; }

  async addAudit(entry) { this.db.audit.push(clone(entry)); if (this.db.audit.length > 5000) this.db.audit.shift(); this._save(); }
}

module.exports = { MemoryStore };
