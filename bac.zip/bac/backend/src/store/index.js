'use strict';
const config = require('../config');
const { MemoryStore } = require('./memory-store');

function createStore(overrides = {}) {
  const url = overrides.databaseUrl !== undefined ? overrides.databaseUrl : config.databaseUrl;
  if (url) {
    const { PgStore } = require('./pg-store');
    return new PgStore({ connectionString: url });
  }
  return new MemoryStore({ file: overrides.dataFile !== undefined ? overrides.dataFile : config.dataFile });
}
module.exports = { createStore, MemoryStore };
