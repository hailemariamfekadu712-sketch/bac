'use strict';
const { createRouter, createServer, bad } = require('./lib/http');
const { createAuthService } = require('./services/auth');
const { createAttemptService } = require('./services/attempts');
const { createContentService } = require('./services/content');
const { importBanks } = require('./importer');
const catalogue = require('./catalogue');

const MAX_LIST = 2000;

/** Build the API. `options.rateLimit:false` turns the login/register limiter off (used by tests). */
function createApp({ store, config, logger = console, rateLimit = true }) {
  const auth = createAuthService({ store, config });
  const attempts = createAttemptService({ store, config });
  const content = createContentService({ store, config });
  const router = createRouter();
  const P = '/api/v1';
  const U = { auth: 'user' };
  const A = { auth: 'admin' };
  const limit = (max, windowMs) => (rateLimit ? { rateLimit: { max, windowMs } } : {});
  const audit = (user, action, detail) => store.addAudit({ at: new Date().toISOString(), actorId: user.id, action, detail });

  router.get(`${P}/health`, async () => ({ status: 'ok', store: store.kind, time: new Date().toISOString() }));

  /* ---------- accounts ---------- */
  router.post(`${P}/auth/register`, limit(20, 10 * 60 * 1000), async ({ body }) => ({ status: 201, json: await auth.register(body) }));
  router.post(`${P}/auth/login`, limit(15, 5 * 60 * 1000), async ({ body }) => auth.login(body));
  router.get(`${P}/users/me`, U, async ({ user }) => ({ user: auth.publicUser(user) }));

  router.patch(`${P}/users/me`, U, async ({ user, body }) => {
    const patch = {};
    if (body.fullName !== undefined) {
      const n = String(body.fullName).trim();
      if (n.length < 2 || n.length > 100) throw bad('Enter your full name (2-100 characters).');
      patch.fullName = n;
    }
    if (body.preferences !== undefined) {
      if (!body.preferences || typeof body.preferences !== 'object' || Array.isArray(body.preferences)) throw bad('"preferences" must be an object.');
      const prefs = { ...(user.preferences || {}) };
      if (body.preferences.theme !== undefined) {
        if (!['light', 'dark'].includes(body.preferences.theme)) throw bad('theme must be "light" or "dark".');
        prefs.theme = body.preferences.theme;
      }
      patch.preferences = prefs;
    }
    return { user: auth.publicUser(await store.updateUser(user.id, patch)) };
  });

  router.post(`${P}/users/me/password`, { ...U, ...limit(10, 10 * 60 * 1000) }, async ({ user, body }) => auth.changePassword(user, body));

  // Same rules as selection.js: Grade 6/8 need a region, Grade 12 needs a stream.
  router.put(`${P}/users/me/selection`, U, async ({ user, body }) => {
    const c = catalogue.resolveCurriculum(body);
    if (!c.ok) throw bad(c.message);
    const updated = await store.updateUser(user.id, { grade: c.grade, region: c.region, stream: c.stream });
    return { selection: { grade: c.grade, region: c.region, stream: c.stream }, user: auth.publicUser(updated) };
  });

  const arrayEndpoint = (field, route) => {
    router.get(`${P}/users/me/${route}`, U, async ({ user }) => ({ [field]: user[field] || [] }));
    router.put(`${P}/users/me/${route}`, { ...U, bodyLimit: 1024 * 1024 }, async ({ user, body }) => {
      const list = body[field];
      if (!Array.isArray(list) || list.length > MAX_LIST) throw bad(`"${field}" must be an array of at most ${MAX_LIST} items.`);
      if (!list.every(i => i && typeof i === 'object' && !Array.isArray(i) && typeof i.id === 'string' && i.id)) throw bad(`Every item in "${field}" needs a text id.`);
      await store.updateUser(user.id, { [field]: list });
      return { [field]: list };
    });
  };
  arrayEndpoint('studyPlan', 'plan');
  arrayEndpoint('flashcards', 'flashcards');

  /* ---------- catalogue (public) ---------- */
  router.get(`${P}/grades`, async () => content.grades());
  router.get(`${P}/exam-types`, async ({ query }) => content.examTypes(query.grade));
  router.get(`${P}/subjects`, async ({ query }) => content.subjects(query));
  router.get(`${P}/questions`, U, async ({ query }) => content.questions(query));

  /* ---------- attempts, results, progress ---------- */
  router.post(`${P}/attempts`, U, async ({ user, body }) => attempts.start(user, body));
  router.get(`${P}/attempts`, U, async ({ user, query }) => attempts.list(user, query));
  router.get(`${P}/attempts/:id`, U, async ({ user, params }) => attempts.get(user, params.id));
  router.put(`${P}/attempts/:id/answers`, U, async ({ user, params, body }) => attempts.saveAnswers(user, params.id, body));
  router.post(`${P}/attempts/:id/submit`, U, async ({ user, params, body }) => attempts.submit(user, params.id, body));
  router.get(`${P}/results/:id`, U, async ({ user, params }) => attempts.result(user, params.id));
  router.get(`${P}/users/me/progress`, U, async ({ user }) => attempts.progress(user));

  /* ---------- resources & announcements ---------- */
  router.get(`${P}/resources`, async ({ query }) => content.resources(query));
  router.get(`${P}/resources/:id`, async ({ params }) => content.resource(params.id));
  router.get(`${P}/announcements`, async () => content.announcements());

  /* ---------- administration ---------- */
  router.get(`${P}/admin/questions/report`, A, async () => content.adminQuestionReport());

  router.post(`${P}/admin/questions/import`, A, async ({ user }) => {
    const report = await importBanks(store, config.bankDir);
    await audit(user, 'questions.import', report.totals);
    return report;
  });

  router.post(`${P}/admin/questions/upload`, { ...A, bodyLimit: 5 * 1024 * 1024 }, async ({ user, body }) => {
    const out = await content.adminUploadQuestions(body);
    await audit(user, 'questions.upload', { bank: out.bank, saved: out.saved, mode: out.mode });
    return { status: 201, json: out };
  });

  router.put(`${P}/admin/announcements/:id`, A, async ({ user, params, body }) => {
    const out = await content.adminUpsertAnnouncement(params.id, body);
    await audit(user, 'announcement.upsert', { id: params.id });
    return out;
  });
  router.delete(`${P}/admin/announcements/:id`, A, async ({ user, params }) => {
    await store.deleteAnnouncement(params.id); await audit(user, 'announcement.delete', { id: params.id }); return { ok: true };
  });
  router.put(`${P}/admin/resources/:id`, A, async ({ user, params, body }) => {
    const out = await content.adminUpsertResource(params.id, body);
    await audit(user, 'resource.upsert', { id: params.id });
    return out;
  });
  router.delete(`${P}/admin/resources/:id`, A, async ({ user, params }) => {
    await store.deleteResource(params.id); await audit(user, 'resource.delete', { id: params.id }); return { ok: true };
  });

  const server = createServer({ router, authenticate: auth.authenticate, corsOrigins: config.corsOrigins, logger });
  return { server, content };
}

module.exports = { createApp };
