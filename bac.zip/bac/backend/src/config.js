'use strict';
const path = require('node:path');
const crypto = require('node:crypto');

const root = path.resolve(__dirname, '..');
const env = process.env;
const isProd = env.NODE_ENV === 'production';

let jwtSecret = env.JWT_SECRET;
if (!jwtSecret || jwtSecret === 'change-me') {
  if (isProd) throw new Error('JWT_SECRET must be set to a long random value in production.');
  jwtSecret = crypto.randomBytes(32).toString('hex');
  if (/server\.js$/.test(process.argv[1] || '')) console.warn('[config] JWT_SECRET not set: using a temporary secret (logins reset on restart).');
}

module.exports = {
  root,
  isProd,
  port: Number(env.PORT) || 3000,
  jwtSecret,
  jwtTtlSeconds: (Number(env.JWT_TTL_HOURS) || 168) * 3600,
  databaseUrl: env.DATABASE_URL || '',
  corsOrigins: (env.CORS_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean),
  bankDir: path.resolve(root, env.QUESTION_BANK_DIR || './question-banks'),
  contentDir: path.resolve(root, './content'),
  dataFile: path.resolve(root, env.DATA_FILE || './data/dev-db.json'),
  importOnStart: env.IMPORT_ON_START !== 'false',
  exam: {
    defaultPracticeMinutes: 30,   // exam.html default
    defaultMockMinutes: 60,       // exam-engine.js default
    maxMinutes: 300,              // exam-engine.js cap
    submitGraceSeconds: 15        // network slack after the deadline
  }
};
