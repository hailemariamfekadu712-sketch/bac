-- Habesha Exam Center: initial schema (PostgreSQL 13+)
-- Grades, regions, streams and subjects live in src/catalogue.js (the single
-- source of truth shared with the frontend), so they are not duplicated here.

CREATE TABLE IF NOT EXISTS users (
  id            text PRIMARY KEY,
  email         text NOT NULL UNIQUE,
  full_name     text NOT NULL,
  password_hash text NOT NULL,
  role          text NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
  grade         text NOT NULL DEFAULT '',
  region        text NOT NULL DEFAULT '',
  stream        text NOT NULL DEFAULT '',
  preferences   jsonb NOT NULL DEFAULT '{}',
  study_plan    jsonb NOT NULL DEFAULT '[]',
  flashcards    jsonb NOT NULL DEFAULT '[]',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS question_banks (
  key           text PRIMARY KEY,            -- e.g. grade6-amhara-english
  grade         text NOT NULL,
  region        text NOT NULL DEFAULT '',
  stream        text NOT NULL DEFAULT '',
  subject       text NOT NULL,
  subject_title text NOT NULL,
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS questions (
  bank_key    text NOT NULL REFERENCES question_banks(key) ON DELETE CASCADE,
  qid         text NOT NULL,                 -- the id written in the bank file
  position    integer NOT NULL,
  topic       text NOT NULL DEFAULT 'General',
  question    text NOT NULL,
  options     jsonb NOT NULL,
  answer      integer NOT NULL,
  explanation text NOT NULL DEFAULT '',
  year        text,
  source      text NOT NULL DEFAULT '',
  difficulty  text CHECK (difficulty IN ('easy','medium','hard')),
  status      text NOT NULL DEFAULT 'published' CHECK (status IN ('published','draft')),
  PRIMARY KEY (bank_key, qid)
);
CREATE INDEX IF NOT EXISTS questions_bank_status_idx ON questions (bank_key, status, position);

CREATE TABLE IF NOT EXISTS attempts (
  id           text PRIMARY KEY,
  user_id      text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bank_key     text NOT NULL,
  status       text NOT NULL CHECK (status IN ('in_progress','submitted')),
  started_at   timestamptz NOT NULL,
  completed_at timestamptz,
  data         jsonb NOT NULL                -- questions order, answers, graded result
);
CREATE INDEX IF NOT EXISTS attempts_user_idx ON attempts (user_id, started_at DESC);

CREATE TABLE IF NOT EXISTS resources     (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS announcements (id text PRIMARY KEY, data jsonb NOT NULL);

CREATE TABLE IF NOT EXISTS audit_logs (
  id       bigserial PRIMARY KEY,
  at       timestamptz NOT NULL DEFAULT now(),
  actor_id text,
  action   text NOT NULL,
  detail   jsonb NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
