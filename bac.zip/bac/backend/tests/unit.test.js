'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const catalogue = require('../src/catalogue');
const { parseBankSource } = require('../src/bank-parser');
const { scanBankDirectory } = require('../src/importer');
const { gradeAttempt } = require('../src/services/attempts');
const { hashPassword, verifyPassword, signToken, verifyToken } = require('../src/lib/security');
const { bankSource } = require('./helpers');

const BANK = catalogue.getBank('grade8-amhara-mathematics');
const q = (over = {}) => ({ id: 'a', question: 'Q?', options: ['x', 'y'], answer: 0, ...over });
const parse = (questions, subject = 'mathematics') => parseBankSource(bankSource(subject, questions), BANK);

test('catalogue has the 54 subject banks the frontend expects', () => {
  assert.equal(catalogue.allBanks().length, 54);
  assert.equal(catalogue.bankFilename({ grade: '6', region: 'Addis Ababa' }, 'ict'), 'grade6-addis-ict.js');
  assert.equal(catalogue.bankFilename({ grade: '12', stream: 'natural science' }, 'aptitude'), 'grade12-natural-aptitude.js');
  assert.equal(catalogue.bankFilename({ grade: '8', region: 'amhara' }, 'general-science'), null); // not a Grade 8 subject
  assert.equal(catalogue.resolveCurriculum({ grade: '6' }).ok, false);
  assert.equal(catalogue.resolveCurriculum({ grade: '12', region: 'amhara' }).ok, false);
});

test('legacy file names: only unambiguous aliases are mapped', () => {
  assert.equal(catalogue.resolveBankFilename('grade6-addis-citizenship-education.js').bank.key, 'grade6-addis-citizenship');
  assert.equal(catalogue.resolveBankFilename('grade8-amhara-information-technology.js').bank.key, 'grade8-amhara-ict');
  assert.equal(catalogue.resolveBankFilename('grade6-amhara-music.js').ok, false);
  assert.equal(catalogue.resolveBankFilename('grade8-amhara-general-science.js').ok, false);
});

test('bank parser accepts good questions and reports every bad one', () => {
  const good = parse([q({ id: '1' }), q({ id: '2', question: 'Other?' })]);
  assert.equal(good.questions.length, 2);
  assert.deepEqual(good.errors, []);

  const cases = [
    [q({ answer: 'x' }), /answer/],
    [q({ answer: 5 }), /answer/],
    [q({ options: ['only one'] }), /options/],
    [q({ options: ['same', 'Same'] }), /identical/],
    [q({ question: '  ' }), /question/],
    [q({ id: undefined }), /no id/],
    [q({ id: 'has space' }), /no spaces/],
    [q({ status: 'weird' }), /status/],
    [q({ options: [1, 2] }), /option/]
  ];
  for (const [bad, re] of cases) {
    const r = parse([bad]);
    assert.equal(r.questions.length, 0, JSON.stringify(bad));
    assert.match(r.errors.join(' '), re);
  }
  assert.match(parse([q({ id: '1' }), q({ id: '1', question: 'B?' })]).errors.join(), /duplicate id/);
  assert.match(parse([q({ id: '1' }), q({ id: '2' })]).errors.join(), /same question text/);
});

test('bank parser rejects a subject mismatch and hostile files', () => {
  assert.match(parse([q()], 'physics').errors.join(), /subject/);
  const evil = parseBankSource('process.exit(1); window.HEC_QUESTION_BANK={subject:"mathematics",questions:[]}', BANK);
  assert.match(evil.errors.join(), /could not be read/);
  const loop = parseBankSource('while(true){}', BANK);
  assert.match(loop.errors.join(), /could not be read/);
  const blank = parseBankSource('window.HEC_QUESTION_BANK={subject:"mathematics",questions:[ /* none */ ]};', BANK);
  assert.deepEqual([blank.errors.length, blank.total], [0, 0]);
});

test('importer scan: alias, unknown, duplicate and missing files', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hec-scan-'));
  const w = (n, subj, qs) => fs.writeFileSync(path.join(dir, n), bankSource(subj, qs));
  w('grade6-addis-citizenship-education.js', 'citizenship', [q()]);
  w('grade6-addis-music.js', 'music', [q()]);
  w('grade6-addis-citizenship.js', 'citizenship', [q({ id: 'z' })]);   // same bank as the alias
  fs.writeFileSync(path.join(dir, '_TEMPLATE.js'), '');
  const r = scanBankDirectory(dir);
  assert.equal(r.files.length, 1);
  assert.equal(r.unknown.length, 2);
  assert.equal(r.missing.length, 53);
});

test('grading is computed from the stored snapshot', () => {
  const a = { answers: { a: 1, b: 0 }, marked: { b: true }, questions: [
    { qid: 'a', topic: 'T', question: 'q', options: ['x', 'y'], answer: 1, explanation: '' },
    { qid: 'b', topic: 'T', question: 'q', options: ['x', 'y'], answer: 1, explanation: '' },
    { qid: 'c', topic: 'T', question: 'q', options: ['x', 'y'], answer: 0, explanation: '' }] };
  const g = gradeAttempt(a);
  assert.deepEqual([g.correct, g.incorrect, g.unanswered, g.percentage], [1, 1, 1, 33]);
  assert.equal(g.review[1].markedForReview, true);
});

test('passwords and tokens', async () => {
  const h = await hashPassword('secret-pass');
  assert.ok(await verifyPassword('secret-pass', h));
  assert.ok(!(await verifyPassword('wrong', h)));
  assert.ok(!(await verifyPassword('x', 'garbage')));
  const t = signToken({ sub: 'u1' }, 's', 60);
  assert.equal(verifyToken(t, 's').sub, 'u1');
  assert.equal(verifyToken(t, 'other'), null);
  assert.equal(verifyToken(t.slice(0, -2) + 'xx', 's'), null);
  assert.equal(verifyToken(signToken({ sub: 'u1' }, 's', -10), 's'), null);
});
