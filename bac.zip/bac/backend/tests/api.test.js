'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startTestServer } = require('./helpers');

const EXAM = { grade: '8', region: 'amhara', subject: 'mathematics' };
let t;
test.before(async () => { t = await startTestServer(); });
test.after(async () => { await t.close(); });

test('health, grades, exam types and subject availability', async () => {
  assert.equal((await t.call('GET', '/health')).body.status, 'ok');
  assert.equal((await t.call('GET', '/grades')).body.grades.length, 3);
  assert.equal((await t.call('GET', '/exam-types?grade=12')).body.examName, 'Ethiopian University Entrance Examination');
  const subs = (await t.call('GET', '/subjects?grade=8&region=amhara')).body;
  assert.equal(subs.subjects.length, 11);
  const math = subs.subjects.find(s => s.id === 'mathematics');
  assert.deepEqual([math.questionCount, math.available], [4, true]);        // the draft question is not counted
  assert.equal(subs.subjects.find(s => s.id === 'english').available, false);
  assert.equal((await t.call('GET', '/subjects?grade=8')).status, 400);     // region required
  assert.equal((await t.call('GET', '/nope')).status, 404);
  assert.equal((await t.call('DELETE', '/grades')).status, 405);
});

test('register / login validation and duplicate email', async () => {
  const r = await t.call('POST', '/auth/register', { body: { fullName: 'Abebe Kebede', email: 'Abebe@Example.com', password: 'password123', grade: '8' } });
  assert.equal(r.status, 201);
  assert.ok(r.body.token);
  assert.equal(r.body.user.email, 'abebe@example.com');
  assert.equal(r.body.user.passwordHash, undefined);
  assert.equal((await t.call('POST', '/auth/register', { body: { fullName: 'X Y', email: 'abebe@example.com', password: 'password123' } })).status, 409);
  assert.equal((await t.call('POST', '/auth/register', { body: { fullName: 'X Y', email: 'bad', password: 'password123' } })).status, 400);
  assert.equal((await t.call('POST', '/auth/register', { body: { fullName: 'X Y', email: 'a@b.co', password: 'short' } })).status, 400);
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'abebe@example.com', password: 'wrongpass1' } })).status, 401);
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'nobody@example.com', password: 'password123' } })).status, 401);
  const ok = await t.call('POST', '/auth/login', { body: { email: 'ABEBE@example.com', password: 'password123' } });
  assert.equal(ok.status, 200);
  assert.equal((await t.call('GET', '/users/me', { token: ok.body.token })).body.user.fullName, 'Abebe Kebede');
  assert.equal((await t.call('GET', '/users/me')).status, 401);
  assert.equal((await t.call('GET', '/users/me', { token: 'garbage.token.here' })).status, 401);
});

test('full exam journey: start, autosave, submit, review, history, progress', async () => {
  const { token } = await t.register('student1@example.com');

  const start = await t.call('POST', '/attempts', { token, body: { ...EXAM, examType: 'practice', durationMinutes: 30 } });
  assert.equal(start.status, 201);
  const a = start.body;
  assert.equal(a.totalQuestions, 4);                    // published only
  assert.equal(a.durationSeconds, 1800);
  assert.equal(a.status, 'in_progress');
  // The correct answer must never be sent before grading.
  const raw = JSON.stringify(a);
  assert.ok(!('answer' in a.questions[0]) && !/explanation|correctAnswer/.test(raw));
  assert.deepEqual(Object.keys(a.questions[0]).sort(), ['id', 'options', 'question', 'topic']);
  assert.ok((await t.call('GET', `/attempts/${a.id}`, { token })).body.questions.every(q => !('answer' in q)));
  assert.ok(!/"answer"/.test(JSON.stringify((await t.call('GET', '/questions?grade=8&region=amhara&subject=mathematics', { token })).body)));

  // autosave: m1 correct(1), m2 wrong(0), m3 correct(1), m4 left blank
  let s = await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m1: 1, m2: 0 }, marked: { m2: true }, currentIndex: 1 } });
  assert.equal(s.status, 200);
  assert.equal(s.body.saved, 2);
  s = await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m3: 1, m2: null } } });  // null clears
  assert.equal(s.body.saved, 2);
  assert.equal((await t.call('GET', `/attempts/${a.id}`, { token })).body.currentIndex, 1);

  // invalid saves are rejected
  assert.equal((await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m1: 9 } } })).status, 400);
  assert.equal((await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { nope: 0 } } })).status, 400);
  assert.equal((await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m1: '1' } } })).status, 400);

  // result not available before submit
  assert.equal((await t.call('GET', `/results/${a.id}`, { token })).status, 409);

  // client-sent scores are ignored; the server grades
  const sub = await t.call('POST', `/attempts/${a.id}/submit`, { token, body: { score: 100, percentage: 100, answers: { m4: 1 } } });
  assert.equal(sub.status, 200);
  const r = sub.body;
  assert.equal(r.status, 'submitted');
  assert.deepEqual([r.correct, r.correctAnswers, r.incorrect, r.unanswered, r.totalQuestions, r.percentage], [3, 3, 0, 1, 4, 75]);
  assert.equal(r.review.length, 4);
  assert.deepEqual(r.questions, r.review);                                        // frontend alias present
  assert.equal(r.review.find(x => x.id === 'm4').isCorrect, true);                // m4 answer 1 came with the submit
  assert.equal(r.review[0].correctAnswer, 1);
  assert.equal(r.review[0].explanation, '2x = 8');
  assert.equal(r.review.find(x => x.id === 'm2').status, 'unanswered');

  // submitting twice returns the same result and cannot change the score
  const again = await t.call('POST', `/attempts/${a.id}/submit`, { token, body: { answers: { m1: 0 } } });
  assert.equal(again.body.percentage, r.percentage);
  assert.equal(again.body.completedAt, r.completedAt);
  assert.equal((await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m1: 0 } } })).status, 409);

  assert.equal((await t.call('GET', `/results/${a.id}`, { token })).body.percentage, 75);

  const list = (await t.call('GET', '/attempts?status=submitted', { token })).body;
  assert.equal(list.total, 1);
  assert.equal(list.attempts[0].review, undefined);       // summaries stay light
  assert.equal(list.attempts[0].percentage, 75);

  const prog = (await t.call('GET', '/users/me/progress', { token })).body;
  assert.deepEqual([prog.totalAttempts, prog.averagePercentage, prog.bestPercentage], [1, 75, 75]);
  assert.equal(prog.bySubject[0].subject, 'mathematics');
  assert.ok(prog.byTopic.some(x => x.topic === 'Geometry' && x.accuracy === 100));
});

test('students cannot see or change each other\'s attempts', async () => {
  const a = await t.register('owner@example.com');
  const b = await t.register('intruder@example.com');
  const att = (await t.call('POST', '/attempts', { token: a.token, body: EXAM })).body;
  for (const [m, route, body] of [['GET', `/attempts/${att.id}`], ['PUT', `/attempts/${att.id}/answers`, { answers: { m1: 1 } }],
    ['POST', `/attempts/${att.id}/submit`, {}], ['GET', `/results/${att.id}`]]) {
    assert.equal((await t.call(m, route, { token: b.token, body })).status, 404, `${m} ${route}`);
  }
  assert.equal((await t.call('GET', '/attempts', { token: b.token })).body.total, 0);
  assert.equal((await t.call('GET', `/attempts/${att.id}`)).status, 401);
});

test('start validations and subjects without questions', async () => {
  const { token } = await t.register('validator@example.com');
  const post = body => t.call('POST', '/attempts', { token, body });
  const empty = await post({ grade: '8', region: 'amhara', subject: 'english' });
  assert.equal(empty.status, 404);
  assert.equal(empty.body.error.code, 'QUESTIONS_NOT_AVAILABLE');
  assert.equal((await post({ grade: '8', region: 'amhara', subject: 'art' })).status, 400);             // not a Grade 8 subject
  assert.equal((await post({ grade: '8', subject: 'mathematics' })).status, 400);                       // no region
  assert.equal((await post({ ...EXAM, examType: 'weird' })).status, 400);
  assert.equal((await post({ ...EXAM, durationMinutes: -5 })).status, 400);
  assert.equal((await post({ ...EXAM, questionCount: 0 })).status, 400);
  const capped = (await post({ ...EXAM, durationMinutes: 9999, examType: 'mock' })).body;
  assert.equal(capped.durationSeconds, 300 * 60);
  assert.equal((await post({ ...EXAM, examType: 'mock' })).body.durationSeconds, 3600);
  assert.equal((await post({ ...EXAM, questionCount: 2 })).body.totalQuestions, 2);
});

test('timer is enforced by the server', async () => {
  const { token } = await t.register('late@example.com');
  const a = (await t.call('POST', '/attempts', { token, body: EXAM })).body;
  await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m1: 1 } } });

  const rec = await t.store.getAttempt(a.id);                     // pretend the deadline passed a minute ago
  rec.deadline = new Date(Date.now() - 60000).toISOString();
  await t.store.saveAttempt(rec);

  const late = await t.call('PUT', `/attempts/${a.id}/answers`, { token, body: { answers: { m2: 1 } } });
  assert.equal(late.status, 409);
  assert.equal(late.body.error.code, 'TIME_EXPIRED');

  const sub = await t.call('POST', `/attempts/${a.id}/submit`, { token, body: { answers: { m2: 1, m3: 1, m4: 1 } } });
  assert.equal(sub.status, 200);
  assert.equal(sub.body.timedOut, true);
  assert.equal(sub.body.correct, 1);                              // late answers were ignored; the autosaved one counts
  assert.equal(sub.body.unanswered, 3);
});

test('selection, profile, password, plan and flashcards', async () => {
  const { token } = await t.register('profile@example.com');
  assert.equal((await t.call('PUT', '/users/me/selection', { token, body: { grade: '12' } })).status, 400);
  assert.equal((await t.call('PUT', '/users/me/selection', { token, body: { grade: '6', region: 'mars' } })).status, 400);
  const sel = await t.call('PUT', '/users/me/selection', { token, body: { grade: '12', stream: 'Natural Science', region: 'amhara' } });
  assert.deepEqual(sel.body.selection, { grade: '12', region: '', stream: 'natural' });

  assert.equal((await t.call('PATCH', '/users/me', { token, body: { fullName: 'Renamed Person', preferences: { theme: 'dark' } } })).body.user.preferences.theme, 'dark');
  assert.equal((await t.call('PATCH', '/users/me', { token, body: { preferences: { theme: 'neon' } } })).status, 400);

  assert.equal((await t.call('POST', '/users/me/password', { token, body: { currentPassword: 'nope', newPassword: 'newpassword1' } })).status, 400);
  assert.equal((await t.call('POST', '/users/me/password', { token, body: { currentPassword: 'password123', newPassword: 'newpassword1' } })).status, 200);
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'profile@example.com', password: 'password123' } })).status, 401);
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'profile@example.com', password: 'newpassword1' } })).status, 200);

  const plan = [{ id: 't1', title: 'Revise algebra', subject: 'mathematics', dueDate: '2026-11-01', completed: false }];
  assert.deepEqual((await t.call('PUT', '/users/me/plan', { token, body: { studyPlan: plan } })).body.studyPlan, plan);
  assert.deepEqual((await t.call('GET', '/users/me/plan', { token })).body.studyPlan, plan);
  assert.equal((await t.call('PUT', '/users/me/plan', { token, body: { studyPlan: [{ title: 'no id' }] } })).status, 400);
  const cards = [{ id: 'c1', front: 'Q', back: 'A', known: false }];
  assert.deepEqual((await t.call('PUT', '/users/me/flashcards', { token, body: { flashcards: cards } })).body.flashcards, cards);
});

test('resources and announcements are seeded from the frontend data', async () => {
  const res = (await t.call('GET', '/resources')).body.resources;
  assert.equal(res.length, 13);
  assert.ok((await t.call('GET', '/resources?subject=english')).body.resources.every(r => r.subject === 'english'));
  assert.equal((await t.call('GET', '/resources/english-notes')).body.id, 'english-notes');
  assert.equal((await t.call('GET', '/resources/missing')).status, 404);
  const ann = (await t.call('GET', '/announcements')).body.announcements;
  assert.equal(ann.length, 3);
  assert.ok(ann[0].priority <= ann[1].priority);
});

test('admin: role checks, atomic question upload, append, import, report', async () => {
  const student = await t.register('plain@example.com');
  assert.equal((await t.call('GET', '/admin/questions/report', { token: student.token })).status, 403);
  assert.equal((await t.call('GET', '/admin/questions/report')).status, 401);

  const { hashPassword, newId } = require('../src/lib/security');
  await t.store.createUser({ id: newId('hec'), email: 'admin@example.com', fullName: 'Admin', passwordHash: await hashPassword('adminpass1'),
    role: 'admin', grade: '', region: '', stream: '', preferences: {}, studyPlan: [], flashcards: [], createdAt: new Date().toISOString() });
  const token = (await t.call('POST', '/auth/login', { body: { email: 'admin@example.com', password: 'adminpass1' } })).body.token;

  const target = { grade: '6', region: 'addis-ababa', subject: 'english' };
  const q = (id, text, answer = 0) => ({ id, question: text, options: ['a', 'b', 'c'], answer, topic: 'Grammar' });

  // one bad question -> nothing saved, all problems listed
  const rej = await t.call('POST', '/admin/questions/upload', { token, body: { ...target, questions: [q('e1', 'First?'), q('e2', 'Second?', 7), q('e3', 'First?')] } });
  assert.equal(rej.status, 400);
  assert.equal(rej.body.error.details.errors.length, 2);
  assert.equal((await t.call('POST', '/attempts', { token: student.token, body: target })).status, 404);

  const ok = await t.call('POST', '/admin/questions/upload', { token, body: { ...target, questions: [q('e1', 'First?'), q('e2', 'Second?', 2)] } });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.saved, 2);
  const app = await t.call('POST', '/admin/questions/upload', { token, body: { ...target, mode: 'append', questions: [q('e3', 'Third?')] } });
  assert.equal(app.body.saved, 3);
  assert.equal((await t.call('POST', '/admin/questions/upload', { token, body: { ...target, mode: 'append', questions: [q('e3', 'Dup?')] } })).status, 400);

  const att = await t.call('POST', '/attempts', { token: student.token, body: target });
  assert.equal(att.body.totalQuestions, 3);

  // re-importing from disk must not wipe API-uploaded questions when the file is empty/absent for that bank
  const rep = await t.call('POST', '/admin/questions/import', { token });
  assert.equal(rep.status, 200);
  assert.equal((await t.call('GET', '/subjects?grade=6&region=addis-ababa', {})).body.subjects.find(s => s.id === 'english').questionCount, 3);

  const report = (await t.call('GET', '/admin/questions/report', { token })).body;
  assert.equal(report.banksExpected, 54);
  assert.equal(report.banksWithQuestions, 2);                      // grade8-amhara-mathematics + grade6-addis-english
  assert.equal(report.totalPublished, 7);

  assert.equal((await t.call('PUT', '/admin/announcements/exam-date', { token, body: { title: 'Mock exam', message: 'Saturday 9am' } })).status, 200);
  assert.ok((await t.call('GET', '/announcements')).body.announcements.some(a => a.id === 'exam-date'));
  assert.equal((await t.call('PUT', '/admin/resources/bad id', { token, body: { title: 'x' } })).status, 400);
  assert.equal((await t.call('PUT', '/admin/resources/grade8-math-pdf', { token, body: { title: 'Maths PDF', url: 'javascript:alert(1)' } })).status, 400);
  assert.equal((await t.call('PUT', '/admin/resources/grade8-math-pdf', { token, body: { title: 'Maths PDF', url: 'https://example.org/m.pdf', grade: '8', subject: 'mathematics', type: 'pdf' } })).body.status, 'available');
});

test('malformed input is handled', async () => {
  const res = await fetch(t.base + '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{not json' });
  assert.equal(res.status, 400);
  const big = await fetch(t.base + '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ x: 'a'.repeat(300 * 1024) }) }).catch(() => ({ status: 'closed' }));
  assert.ok([413, 'closed'].includes(big.status));
});
