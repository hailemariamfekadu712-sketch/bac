'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const config = require('../src/config');
const { MemoryStore } = require('../src/store/memory-store');
const { createApp } = require('../src/app');
const { importBanks } = require('../src/importer');

const bankSource = (subject, questions) =>
  `window.HEC_QUESTION_BANK = ${JSON.stringify({ subject, questions }, null, 2)};`;

const GOOD = [
  { id: 'm1', topic: 'Algebra', question: 'Solve 2x + 3 = 11', options: ['3', '4', '5', '7'], answer: 1, explanation: '2x = 8' },
  { id: 'm2', topic: 'Algebra', question: 'What is 5 x 6?', options: ['11', '30', '56', '36'], answer: 1 },
  { id: 'm3', topic: 'Geometry', question: 'Degrees in a triangle?', options: ['90', '180', '270', '360'], answer: 1 },
  { id: 'm4', topic: 'Geometry', question: 'Sides of a hexagon?', options: ['5', '6', '7', '8'], answer: 1 },
  { id: 'd1', topic: 'Geometry', question: 'A hidden draft question?', options: ['x', 'y'], answer: 0, status: 'draft' }
];

async function startTestServer() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hec-banks-'));
  fs.writeFileSync(path.join(dir, 'grade8-amhara-mathematics.js'), bankSource('mathematics', GOOD));
  const store = new MemoryStore();
  await store.init();
  const cfg = { ...config, bankDir: dir, jwtSecret: 'test-secret', exam: { ...config.exam } };
  const { server, content } = createApp({ store, config: cfg, logger: { error() {}, warn() {}, log() {} }, rateLimit: false });
  await content.seed();
  await importBanks(store, dir);
  await new Promise(r => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}/api/v1`;

  async function call(method, route, { token, body } = {}) {
    const res = await fetch(base + route, {
      method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  }
  const register = async (email, extra = {}) =>
    (await call('POST', '/auth/register', { body: { fullName: 'Test Student', email, password: 'password123', grade: '8', ...extra } })).body;

  return { base, call, register, store, cfg, dir, close: async () => { server.close(); await store.close(); } };
}

module.exports = { startTestServer, bankSource, GOOD };
