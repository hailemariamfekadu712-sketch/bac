# Habesha Exam Center: Backend API

Node.js REST API for the HEC frontend. It serves the subject catalogue, grades exams **on the server**
(correct answers are never sent before submission), stores attempts, results and progress, and imports
questions from the same `question-banks/*.js` files the frontend already uses.

* **Runtime:** Node 20+ (tested on 22). **Only dependency:** `pg` (needed only when you use PostgreSQL).
* **Two stores, one interface:** with no `DATABASE_URL` it uses a JSON file (`data/dev-db.json`) so you can
  run everything with zero setup; with `DATABASE_URL` it uses PostgreSQL.
* The HTTP layer is a small built-in router (about 60 lines in `src/lib/http.js`), not Express, so it runs and is
  testable with no package install. Swapping to Express later only touches `src/lib/http.js` and `src/app.js`.

## Run it

```bash
cd backend
npm install                      # only installs `pg`
npm test                         # 17 tests, no database needed
node src/server.js               # http://localhost:3000/api/v1/health
```

Production (PostgreSQL):

```bash
cp .env.example .env             # set JWT_SECRET, DATABASE_URL, CORS_ORIGINS
npm run migrate                  # creates the tables from database/migrations/001_init.sql
npm run create-admin -- you@example.com "a strong password" "Your Name"
NODE_ENV=production node --env-file=.env src/server.js
```

`CORS_ORIGINS` must contain your GitHub Pages origin (for example `https://yourname.github.io`).
GitHub Pages cannot host this API; deploy it on any Node host (Render, Railway, Fly.io, a VPS) with a
PostgreSQL database.

## Adding questions (the blank files)

`question-banks/` holds **54 blank files, one per subject** (`grade6-amhara-english.js` ...
`grade12-social-economics.js`). They match the frontend's subject list exactly. Open a file, add questions
to the `questions` array (the file explains how), then:

```bash
npm run validate:questions                       # checks every file, no database; shows file + question number of any error
npm run import:questions                         # loads them into the database (also runs on server start)
npm run sync:banks -- ../frontend                # copies the files into the frontend so the static site shows them too
```

Format and rules: `question-banks/QUESTION-FORMAT.md`. Invalid questions are **reported, never silently
skipped**, and an uncertain answer should be left out or marked `status: "draft"`.
Admins can also post questions directly: `POST /api/v1/admin/questions/upload` (all-or-nothing).

## API (`/api/v1`)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/health` | none | status |
| POST | `/auth/register`, `/auth/login` | none | returns `{ token, user }` |
| GET/PATCH | `/users/me` | user | profile, theme |
| POST | `/users/me/password` | user | change password |
| PUT | `/users/me/selection` | user | grade + region/stream (same rules as `selection.js`) |
| GET/PUT | `/users/me/plan`, `/users/me/flashcards` | user | planner tasks, flashcards (replace whole list) |
| GET | `/grades`, `/exam-types?grade=`, `/subjects?grade=&region=\|stream=` | none | catalogue + `questionCount`/`available` per subject |
| GET | `/questions?grade=&region=&stream=&subject=` | user | questions **without** answers |
| POST | `/attempts` | user | start `{grade,region\|stream,subject,examType,durationMinutes?,questionCount?,shuffle?}` |
| PUT | `/attempts/:id/answers` | owner | autosave `{answers:{qid:index\|null}, marked?, currentIndex?}` |
| POST | `/attempts/:id/submit` | owner | grade; idempotent; returns result + review with correct answers |
| GET | `/attempts`, `/attempts/:id`, `/results/:id` | owner | history, resume, result |
| GET | `/users/me/progress` | user | totals, per subject, per topic, recent trend |
| GET | `/resources`, `/resources/:id`, `/announcements` | none | seeded from the frontend data |
| POST | `/admin/questions/import`, `/admin/questions/upload` | admin | re-scan files / upload JSON |
| GET | `/admin/questions/report` | admin | questions per subject |
| PUT/DELETE | `/admin/announcements/:id`, `/admin/resources/:id` | admin | manage content |

Rules enforced by the server: bcrypt-class password hashing (scrypt), signed expiring tokens, ownership
checks (another student's attempt returns 404), answers validated against the question's options, the timer
(late autosaves are refused; late answers sent with submit are ignored; the result is flagged `timedOut`),
duplicate submits cannot change a score, login/register rate limits, request size limits.
Results include both field spellings the frontend uses (`correct`/`correctAnswers`, `review`/`questions`).

## Layout

```
src/catalogue.js        grades, regions, streams, subjects (mirrors the frontend)
src/bank-parser.js      safely reads and validates a question-bank file
src/importer.js         scans question-banks/ and syncs the store
src/services/           auth, attempts (grading, progress), content, admin
src/store/              memory-store.js (dev) and pg-store.js (PostgreSQL)
database/migrations/    SQL schema
scripts/                validate, import, sync, migrate, create-admin, frontend parity check
tests/                  unit + API tests
```

Catalogue check against the frontend: `node scripts/check-frontend-parity.js ../frontend`.

## Verified vs not verified

Verified here by running it: all 17 tests (full exam journey over real HTTP, grading, timer, ownership,
admin upload, importer, hostile bank files), the real server booting on the 54 blank files, and
`api-client.js` against the live server.
**Not verified:** `src/store/pg-store.js` and the SQL migration (no PostgreSQL in the build environment).
Run `npm run migrate`, then `npm test` equivalents against your database before going live.
