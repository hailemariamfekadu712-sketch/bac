#!/usr/bin/env node
'use strict';
/* npm run create-admin -- you@example.com "A strong password" "Your Name"  */
const { createStore } = require('../src/store');
const { hashPassword, newId } = require('../src/lib/security');

(async () => {
  const [email, password, name] = process.argv.slice(2);
  if (!email || !password || password.length < 8) {
    console.error('Usage: npm run create-admin -- <email> <password (8+ chars)> ["Full Name"]');
    process.exit(1);
  }
  const store = createStore();
  await store.init();
  const existing = await store.getUserByEmail(email);
  if (existing) {
    await store.updateUser(existing.id, { role: 'admin', passwordHash: await hashPassword(password) });
    console.log(`Updated ${email}: now an administrator with the new password.`);
  } else {
    await store.createUser({ id: newId('hec'), email, fullName: name || 'Administrator', passwordHash: await hashPassword(password),
      role: 'admin', grade: '', region: '', stream: '', preferences: { theme: 'light' }, studyPlan: [], flashcards: [], createdAt: new Date().toISOString() });
    console.log(`Created administrator ${email}.`);
  }
  await store.close();
})().catch(e => { console.error(e); process.exit(1); });
