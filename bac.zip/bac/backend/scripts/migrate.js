#!/usr/bin/env node
'use strict';
/* Apply database/migrations/*.sql to DATABASE_URL, once each:  npm run migrate */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../src/config');

(async () => {
  if (!config.databaseUrl) { console.error('Set DATABASE_URL first (see .env.example).'); process.exit(1); }
  const { Pool } = require('pg');
  const pool = new Pool({ connectionString: config.databaseUrl,
    ssl: /localhost|127\.0\.0\.1|sslmode=disable/.test(config.databaseUrl) ? undefined : { rejectUnauthorized: false } });
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
  const dir = path.join(config.root, 'database', 'migrations');
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) {
    if ((await pool.query('SELECT 1 FROM schema_migrations WHERE name=$1', [file])).rowCount) { console.log('already applied:', file); continue; }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(fs.readFileSync(path.join(dir, file), 'utf8'));
      await client.query('INSERT INTO schema_migrations (name) VALUES ($1) ON CONFLICT DO NOTHING', [file]);
      await client.query('COMMIT');
      console.log('applied:', file);
    } catch (e) { await client.query('ROLLBACK'); console.error('FAILED:', file, e.message); process.exit(1); } finally { client.release(); }
  }
  await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
