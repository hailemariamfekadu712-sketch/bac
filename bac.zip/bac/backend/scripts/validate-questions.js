#!/usr/bin/env node
'use strict';
/*
  Check the question-bank files WITHOUT a database. Run this before every commit:
      npm run validate:questions            (whole folder)
      npm run validate:questions -- grade6-amhara-english.js
  Exit code 1 if any question is invalid, so it also works in CI.
*/
const config = require('../src/config');
const { scanBankDirectory } = require('../src/importer');

const only = process.argv.slice(2).filter(a => !a.startsWith('--'));
const verbose = process.argv.includes('--warnings');
const report = scanBankDirectory(config.bankDir);

let errors = 0, published = 0, withQuestions = 0;
for (const f of report.files) {
  if (only.length && !only.includes(f.file)) continue;
  published += f.published;
  if (f.published > 0) withQuestions++;
  if (f.errors.length || (verbose && f.warnings.length) || f.total > 0) {
    const mark = f.errors.length ? 'FAIL' : 'ok  ';
    console.log(`${mark} ${f.file}: ${f.published} published of ${f.total} question(s)${f.aliasOf ? ` (alias of ${f.aliasOf})` : ''}`);
  }
  for (const e of f.errors) { console.log(`     ✗ ${e}`); errors++; }
  if (verbose) for (const w of f.warnings) console.log(`     ! ${w}`);
}
for (const u of report.unknown) { console.log(`SKIP ${u.file}: ${u.reason}`); }
console.log(`\n${withQuestions}/${report.files.length} bank file(s) have questions; ${published} published question(s); ${errors} error(s).`);
process.exit(errors ? 1 : 0);
