#!/usr/bin/env node
'use strict';
/*
  Confirms this backend's catalogue (src/catalogue.js) still matches the
  frontend's subjects.js and that every subject has a bank file there.
      node scripts/check-frontend-parity.js ../frontend
*/
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const catalogue = require('../src/catalogue');

const dir = process.argv[2];
if (!dir) { console.error('Usage: node scripts/check-frontend-parity.js <frontend-folder>'); process.exit(1); }

const doc = { readyState: 'complete', addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; } };
const win = { localStorage: { getItem() { return null; } } };
vm.runInNewContext(fs.readFileSync(path.join(dir, 'subjects.js'), 'utf8'), { window: win, document: doc, localStorage: win.localStorage, CustomEvent: function () {} });

let problems = 0;
const cases = [['6', { region: 'amhara' }], ['6', { region: 'addis-ababa' }], ['8', { region: 'amhara' }], ['8', { region: 'addis-ababa' }],
  ['12', { stream: 'natural' }], ['12', { stream: 'social' }]];
for (const [grade, sel] of cases) {
  const fe = win.HECSubjects.getSubjects({ grade, ...sel }).map(s => `${s.id}=${s.name}`).join('|');
  const be = catalogue.getSubjects({ grade, ...sel }).map(s => `${s.id}=${s.name}`).join('|');
  if (fe !== be) { problems++; console.log(`MISMATCH grade ${grade} ${JSON.stringify(sel)}\n  frontend: ${fe}\n  backend : ${be}`); }
}
const missing = catalogue.allBanks().filter(b => !fs.existsSync(path.join(dir, b.filename)));
missing.forEach(b => { problems++; console.log('Frontend is missing bank file:', b.filename); });
console.log(problems ? `\n${problems} problem(s).` : 'Catalogue matches the frontend and every subject has a bank file there.');
process.exit(problems ? 1 : 0);
