#!/usr/bin/env node
'use strict';
/*
  The frontend (GitHub Pages) loads its question banks from files in its own
  root folder. Keep question-banks/ here as the one place you edit, then copy:

      npm run sync:banks -- ../frontend            (copies; never overwrites a frontend file that already has questions)
      npm run sync:banks -- ../frontend --force    (overwrite everything)
*/
const fs = require('node:fs');
const path = require('node:path');
const config = require('../src/config');
const catalogue = require('../src/catalogue');

const dest = process.argv[2];
const force = process.argv.includes('--force');
if (!dest || dest.startsWith('--')) { console.error('Usage: npm run sync:banks -- <frontend-folder> [--force]'); process.exit(1); }
if (!fs.existsSync(dest)) { console.error('Folder not found:', dest); process.exit(1); }

let copied = 0, kept = 0;
for (const b of catalogue.allBanks()) {
  const from = path.join(config.bankDir, b.filename);
  const to = path.join(dest, b.filename);
  if (!fs.existsSync(from)) continue;
  if (fs.existsSync(to) && !force && /question\s*:/.test(fs.readFileSync(to, 'utf8')) && fs.readFileSync(to, 'utf8') !== fs.readFileSync(from, 'utf8')) {
    console.log('kept (frontend copy already has questions):', b.filename); kept++; continue;
  }
  fs.copyFileSync(from, to); copied++;
}
console.log(`Copied ${copied} file(s); kept ${kept}.`);
