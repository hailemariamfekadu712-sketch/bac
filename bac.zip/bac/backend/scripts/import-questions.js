#!/usr/bin/env node
'use strict';
/* Sync question-banks/*.js into the database:  npm run import:questions [-- --strict] */
const config = require('../src/config');
const { createStore } = require('../src/store');
const { importBanks } = require('../src/importer');

(async () => {
  const strict = process.argv.includes('--strict');
  const store = createStore();
  await store.init();
  const report = await importBanks(store, config.bankDir);
  await store.close();

  for (const f of report.files) {
    if (f.total === 0 && !f.errors.length) continue;
    console.log(`${f.errors.length ? 'WARN' : 'ok  '} ${f.file}: ${f.published} published / ${f.total} in file` +
      (f.keptDatabase ? ' (file empty: database copy kept)' : ''));
    f.errors.forEach(e => console.log(`     ✗ ${e}`));
  }
  report.unknown.forEach(u => console.log(`SKIP ${u.file}: ${u.reason}`));
  console.log(`\nStore: ${store.kind}. ${report.totals.published} published question(s) in ${report.banksWithQuestions}/${report.banksExpected} subject banks; ${report.totals.errors} rejected question(s).`);
  process.exit(strict && report.totals.errors ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
