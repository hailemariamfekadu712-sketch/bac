/* Copy this file to the exact name of the subject you are filling in, e.g.
   grade8-addis-mathematics.js  (names must match the files already in this folder).
   Files starting with "_" are ignored by the importer. */
window.HEC_QUESTION_BANK = {
  subject: "mathematics",          // must equal the subject id in the file name
  questions: [
    { id: "g8-aa-math-001", topic: "Algebra", question: "Solve: 2x + 3 = 11", options: ["x = 3", "x = 4", "x = 5", "x = 7"], answer: 1, explanation: "2x = 8, so x = 4." },
    { id: "g8-aa-math-002", topic: "Geometry", question: "How many degrees are in the angles of a triangle?", options: ["90", "180", "270", "360"], answer: 1 }
  ]
};
