# Question bank format

Every subject has **one file** in this folder, named `gradeN-<curriculum>-<subject>.js`
(for example `grade6-amhara-english.js`, `grade12-natural-physics.js`). The same file is
read by the **backend** (importer) and by the **frontend** (`exam.html` loads it directly),
so a question is written once.

```js
window.HEC_QUESTION_BANK = {
  subject: "english",            // must match the subject id in the file name
  questions: [
    {
      id: "g6-am-english-001",   // required, unique in the file, no spaces
      topic: "Grammar",          // optional (defaults to "General"); powers topic performance
      question: "Choose the correct word: She ___ to school.",   // required
      options: ["go", "goes", "going", "gone"],                   // required, 2-6 choices, no repeats
      answer: 1,                 // required: POSITION of the correct option (0 = first)
      explanation: "Third person singular takes -es.",            // optional but recommended
      year: 2017,                // optional: exam year (2017 or "2017 E.C.")
      source: "Grade 6 Amharic model paper 2017 E.C.",            // optional
      difficulty: "easy",        // optional: easy | medium | hard
      status: "published"        // optional: published (default) | draft (hidden from students)
    }
  ]
};
```

## Rules the validator enforces
- `answer` is a whole number inside the option list. Writing the answer text is rejected.
- Ids are unique; no two questions have the same text; no two options in a question are the same.
- `bank.subject` must match the file's subject. The frontend refuses a mismatched bank.
- A rejected question is **reported with its number and the reason**; it is never silently dropped.
- Do not guess answers. If you cannot verify one, leave the question out or mark it `status: "draft"`.

## Where each file goes
| Grade | Files |
|---|---|
| 6, 8 | `gradeN-amhara-<subject>.js`, `gradeN-addis-<subject>.js` |
| 12 | `grade12-natural-<subject>.js`, `grade12-social-<subject>.js` |

Subjects per file are defined in `src/catalogue.js` (copied from the frontend's `subjects.js`).

## Workflow
1. Add questions to the file.
2. `npm run validate:questions` (no database needed; exit code 1 on any error).
3. `npm run import:questions` (or restart the server; it imports on start).
4. `npm run sync:banks -- ../frontend` copies the files into the frontend folder so the static site shows them too.

A non-empty file replaces that subject's questions in the database. An **empty** file never
deletes questions that were added through the admin upload API.
