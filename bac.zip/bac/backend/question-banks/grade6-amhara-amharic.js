/* grade6-amhara-amharic.js
   Grade 6 · Amhara · Amharic

   HOW TO ADD QUESTIONS
   1. Add one object per question inside the questions array below (copy the example).
   2. "answer" is the POSITION of the correct option: 0 = first, 1 = second, 2 = third, 3 = fourth.
   3. Every id must be unique in this file and have no spaces.
   4. Only add a question when you have checked the answer against the source paper.
      If you are not sure, leave it out (or add  status: "draft"  so it is not shown to students).
   5. Check your work:  npm run validate:questions -- grade6-amhara-amharic.js
   Full rules: QUESTION-FORMAT.md
*/
window.HEC_QUESTION_BANK = {
  grade: "6",
  region: "amhara",
  stream: "",
  subject: "amharic",
  subjectTitle: "Amharic",
  questions: [
    /* Example (delete the comment marks to use it):
    {
      id: "g6-am-amharic-001",
      topic: "Topic name",
      question: "Write the question here?",
      options: ["Option A", "Option B", "Option C", "Option D"],
      answer: 0,
      explanation: "Why this answer is correct (optional but recommended).",
      year: 2017,                      // optional: exam year
      source: "Paper or book name"     // optional
    },
    */
  ]
};
