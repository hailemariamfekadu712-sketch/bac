# Habesha Exam Center: project

```
frontend/   your original site (unchanged) + 54 question-bank files + api-client.js
backend/    the API, database schema, question importer, tests
```

* Question files: edit them in `backend/question-banks/`, then `npm run sync:banks -- ../frontend`.
* The frontend works exactly as before; it only talks to the backend once you add
  `window.HEC_API_URL` and load `api-client.js` (see the comment at the top of that file).
* Start with `backend/README.md`.
